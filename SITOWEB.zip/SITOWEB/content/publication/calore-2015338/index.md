---
# Documentation: https://wowchemy.com/docs/managing-content/

title: A founder MYBPC3 mutation results in HCM with a high risk of sudden death after
  the fourth decade of life
subtitle: ''
summary: ''
authors:
- C. Calore
- M. De Bortoli
- C. Romualdi
- A. Lorenzon
- A. Angelini
- C. Basso
- G. Thiene
- S. Iliceto
- A. Rampazzo
- P. Melacini
tags: []
categories: []
date: '2015-01-01'
lastmod: 2021-04-06T15:49:38+02:00
featured: false
draft: false

# Featured image
# To use, add an image named `featured.jpg/png` to your page's folder.
# Focal points: Smart, Center, TopLeft, Top, TopRight, Left, Right, BottomLeft, Bottom, BottomRight.
image:
  caption: ''
  focal_point: ''
  preview_only: false

# Projects (optional).
#   Associate this post with one or more of your projects.
#   Simply enter your project's folder or file name without extension.
#   E.g. `projects = ["internal-project"]` references `content/project/deep-learning/index.md`.
#   Otherwise, set `projects = []`.
projects: []
publishDate: '2021-04-06T13:49:38.180356Z'
publication_types:
- '2'
abstract: ''
publication: '*Journal of Medical Genetics*'
url_pdf: https://www.scopus.com/inward/record.uri?eid=2-s2.0-84930634983&doi=10.1136%2fjmedgenet-2014-102923&partnerID=40&md5=09871153d3912153fdd1894bbc4ba81d
doi: 10.1136/jmedgenet-2014-102923
---
