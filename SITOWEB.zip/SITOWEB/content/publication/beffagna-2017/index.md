---
# Documentation: https://wowchemy.com/docs/managing-content/

title: 'Circulating cell-free DNA in dogs with mammary tumors: Short and long fragments
  and integrity index'
subtitle: ''
summary: ''
authors:
- G. Beffagna
- A. Sammarco
- C. Bedin
- C. Romualdi
- M. Mainenti
- A. Mollo
- L. Cavicchioli
- S. Ferro
- D. Trez
- R.D. Maria
- D. Nitti
- A. Saccani
- M. Campanella
- M. Agostini
- V. Zappulli
tags: []
categories: []
date: '2017-01-01'
lastmod: 2021-04-06T15:49:36+02:00
featured: false
draft: false

# Featured image
# To use, add an image named `featured.jpg/png` to your page's folder.
# Focal points: Smart, Center, TopLeft, Top, TopRight, Left, Right, BottomLeft, Bottom, BottomRight.
image:
  caption: ''
  focal_point: ''
  preview_only: false

# Projects (optional).
#   Associate this post with one or more of your projects.
#   Simply enter your project's folder or file name without extension.
#   E.g. `projects = ["internal-project"]` references `content/project/deep-learning/index.md`.
#   Otherwise, set `projects = []`.
projects: []
publishDate: '2021-04-06T13:49:35.915468Z'
publication_types:
- '2'
abstract: ''
publication: '*PLoS ONE*'
url_pdf: https://www.scopus.com/inward/record.uri?eid=2-s2.0-85009380170&doi=10.1371%2fjournal.pone.0169454&partnerID=40&md5=a0ba29be3fea0b3fc56bb9f663e8fafd
doi: 10.1371/journal.pone.0169454
---
