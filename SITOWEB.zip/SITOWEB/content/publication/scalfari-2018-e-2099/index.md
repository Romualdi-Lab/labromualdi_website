---
# Documentation: https://wowchemy.com/docs/managing-content/

title: The cortical damage, early relapses, and onset of the progressive phase in
  multiple sclerosis
subtitle: ''
summary: ''
authors:
- A. Scalfari
- C. Romualdi
- R.S. Nicholas
- M. Mattoscio
- R. Magliozzi
- A. Morra
- S. Monaco
- P.A. Muraro
- M. Calabrese
tags: []
categories: []
date: '2018-01-01'
lastmod: 2021-04-06T15:49:34+02:00
featured: false
draft: false

# Featured image
# To use, add an image named `featured.jpg/png` to your page's folder.
# Focal points: Smart, Center, TopLeft, Top, TopRight, Left, Right, BottomLeft, Bottom, BottomRight.
image:
  caption: ''
  focal_point: ''
  preview_only: false

# Projects (optional).
#   Associate this post with one or more of your projects.
#   Simply enter your project's folder or file name without extension.
#   E.g. `projects = ["internal-project"]` references `content/project/deep-learning/index.md`.
#   Otherwise, set `projects = []`.
projects: []
publishDate: '2021-04-06T13:49:34.488158Z'
publication_types:
- '2'
abstract: ''
publication: '*Neurology*'
url_pdf: https://www.scopus.com/inward/record.uri?eid=2-s2.0-85053906764&doi=10.1212%2fWNL.0000000000005685&partnerID=40&md5=bb2a0854d94493062066d1f16d166289
doi: 10.1212/WNL.0000000000005685
---
