---
# Documentation: https://wowchemy.com/docs/managing-content/

title: 'Polymorphisms in von Willebrand factor gene promoter influence the glucocorticoid-induced
  increase in von Willebrand factor: The lesson learned from Cushing syndrome'
subtitle: ''
summary: ''
authors:
- A. Casonato
- V. Daidone
- F. Sartorello
- N. Albiger
- C. Romualdi
- F. Mantero
- A. Pagnan
- C. Scaroni
tags: []
categories: []
date: '2008-01-01'
lastmod: 2021-04-06T15:49:46+02:00
featured: false
draft: false

# Featured image
# To use, add an image named `featured.jpg/png` to your page's folder.
# Focal points: Smart, Center, TopLeft, Top, TopRight, Left, Right, BottomLeft, Bottom, BottomRight.
image:
  caption: ''
  focal_point: ''
  preview_only: false

# Projects (optional).
#   Associate this post with one or more of your projects.
#   Simply enter your project's folder or file name without extension.
#   E.g. `projects = ["internal-project"]` references `content/project/deep-learning/index.md`.
#   Otherwise, set `projects = []`.
projects: []
publishDate: '2021-04-06T13:49:46.145609Z'
publication_types:
- '2'
abstract: ''
publication: '*British Journal of Haematology*'
url_pdf: https://www.scopus.com/inward/record.uri?eid=2-s2.0-37249027758&doi=10.1111%2fj.1365-2141.2007.06907.x&partnerID=40&md5=8a2f4614a9a2bd79985f463c3aa2d503
doi: 10.1111/j.1365-2141.2007.06907.x
---
