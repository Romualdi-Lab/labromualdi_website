---
# Documentation: https://wowchemy.com/docs/managing-content/

title: Selection of multipotent cells and enhanced muscle reconstruction by myogenic
  macrophage-secreted factors
subtitle: ''
summary: ''
authors:
- A. Malerba
- L. Vitiello
- D. Segat
- E. Dazzo
- M. Frigo
- I. Scambi
- P. De Coppi
- L. Boldrin
- L. Martelli
- A. Pasut
- C. Romualdi
- R.G. Bellomo
- J. Vecchiet
- M.D. Baroni
tags: []
categories: []
date: '2009-01-01'
lastmod: 2021-04-06T15:49:45+02:00
featured: false
draft: false

# Featured image
# To use, add an image named `featured.jpg/png` to your page's folder.
# Focal points: Smart, Center, TopLeft, Top, TopRight, Left, Right, BottomLeft, Bottom, BottomRight.
image:
  caption: ''
  focal_point: ''
  preview_only: false

# Projects (optional).
#   Associate this post with one or more of your projects.
#   Simply enter your project's folder or file name without extension.
#   E.g. `projects = ["internal-project"]` references `content/project/deep-learning/index.md`.
#   Otherwise, set `projects = []`.
projects: []
publishDate: '2021-04-06T13:49:44.959409Z'
publication_types:
- '2'
abstract: ''
publication: '*Experimental Cell Research*'
url_pdf: https://www.scopus.com/inward/record.uri?eid=2-s2.0-62049084508&doi=10.1016%2fj.yexcr.2009.01.005&partnerID=40&md5=be035241b1adcd0cb7d949272f87062b
doi: 10.1016/j.yexcr.2009.01.005
---
