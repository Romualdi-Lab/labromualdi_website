---
# Documentation: https://wowchemy.com/docs/managing-content/

title: 'Transcriptional Characterization of Stage I Epithelial Ovarian Cancer: A Multicentric
  Study'
subtitle: ''
summary: ''
authors:
- E. Calura
- M. Ciciani
- A. Sambugaro
- L. Paracchini
- G. Benvenuto
- S. Milite
- P. Martini
- L. Beltrame
- F. Zane
- R. Fruscio
- M.D. Marchette
- F. Borella
- G. Tognon
- A. Ravaggi
- D. Katsaros
- E. Bignotti
- F. Odicino
- M. D'Incalci
- S. Marchini
- C. Romualdi
tags: []
categories: []
date: '2019-01-01'
lastmod: 2021-04-06T15:49:32+02:00
featured: false
draft: false

# Featured image
# To use, add an image named `featured.jpg/png` to your page's folder.
# Focal points: Smart, Center, TopLeft, Top, TopRight, Left, Right, BottomLeft, Bottom, BottomRight.
image:
  caption: ''
  focal_point: ''
  preview_only: false

# Projects (optional).
#   Associate this post with one or more of your projects.
#   Simply enter your project's folder or file name without extension.
#   E.g. `projects = ["internal-project"]` references `content/project/deep-learning/index.md`.
#   Otherwise, set `projects = []`.
projects: []
publishDate: '2021-04-06T13:49:32.502267Z'
publication_types:
- '2'
abstract: ''
publication: '*Cells*'
url_pdf: https://www.scopus.com/inward/record.uri?eid=2-s2.0-85089129095&doi=10.3390%2fcells8121554&partnerID=40&md5=d8a562e589491b2569ac991dab327b54
doi: 10.3390/cells8121554
---
