---
# Documentation: https://wowchemy.com/docs/managing-content/

title: Pericentriolar material analyses in normal esophageal mucosa, Barrett's metaplasia
  and adenocarcinoma
subtitle: ''
summary: ''
authors:
- D. Segat
- M. Cassaro
- E. Dazzo
- L. Cavallini
- C. Romualdi
- R. Salvador
- M.P. Vitale
- L. Vitiello
- M. Fassan
- M. Rugge
- G. Zaninotto
- E. Ancona
- M.D. Baroni
tags: []
categories: []
date: '2010-01-01'
lastmod: 2021-04-06T15:49:43+02:00
featured: false
draft: false

# Featured image
# To use, add an image named `featured.jpg/png` to your page's folder.
# Focal points: Smart, Center, TopLeft, Top, TopRight, Left, Right, BottomLeft, Bottom, BottomRight.
image:
  caption: ''
  focal_point: ''
  preview_only: false

# Projects (optional).
#   Associate this post with one or more of your projects.
#   Simply enter your project's folder or file name without extension.
#   E.g. `projects = ["internal-project"]` references `content/project/deep-learning/index.md`.
#   Otherwise, set `projects = []`.
projects: []
publishDate: '2021-04-06T13:49:43.682674Z'
publication_types:
- '2'
abstract: ''
publication: '*Histology and Histopathology*'
url_pdf: https://www.scopus.com/inward/record.uri?eid=2-s2.0-77953052483&partnerID=40&md5=f7197c1c94301e663c7dd54b326e2f26
---
