+++
title = "Copy number alterations in stage I epithelial ovarian cancer highlight three genomic patterns associated with prognosis"
date = "2022-01-01"
authors = ["C. Pesenti", "L. Beltrame", "A. Velle", "R. Fruscio", "M. Jaconi", "F. Borella", "F.M. Cribiu", "E. Calura", "L.V. Venturini", "D. Lenoci", "F. Agostinis", "D. Katsaros", "N. Panini", "T. Bianchi", "F. Landoni", "M. Miozzo", "M. D'Incalci", "J.D. Brenton", "C. Romualdi", "S. Marchini"]
publication_types = ["2"]
publication = "European Journal of Cancer, (171), _pp. 85-95_, https://doi.org/10.1016/j.ejca.2022.05.005"
publication_short = "European Journal of Cancer, (171), _pp. 85-95_, https://doi.org/10.1016/j.ejca.2022.05.005"
abstract = ""
abstract_short = ""
image_preview = ""
selected = false
projects = []
tags = []
url_pdf = ""
url_preprint = ""
url_code = ""
url_dataset = ""
url_project = ""
url_slides = ""
url_video = ""
url_poster = ""
url_source = ""
math = true
highlight = true
[header]
image = ""
caption = ""
+++
