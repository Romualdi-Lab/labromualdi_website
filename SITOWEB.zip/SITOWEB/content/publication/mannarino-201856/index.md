---
# Documentation: https://wowchemy.com/docs/managing-content/

title: A systems biology approach to investigate the mechanism of action of trabectedin
  in a model of myelomonocytic leukemia
subtitle: ''
summary: ''
authors:
- L. Mannarino
- L. Paracchini
- I. Craparotta
- M. Romano
- S. Marchini
- R. Gatta
- E. Erba
- L. Clivio
- C. Romualdi
- M. D'Incalci
- L. Beltrame
- L. Pattini
tags: []
categories: []
date: '2018-01-01'
lastmod: 2021-04-06T15:49:34+02:00
featured: false
draft: false

# Featured image
# To use, add an image named `featured.jpg/png` to your page's folder.
# Focal points: Smart, Center, TopLeft, Top, TopRight, Left, Right, BottomLeft, Bottom, BottomRight.
image:
  caption: ''
  focal_point: ''
  preview_only: false

# Projects (optional).
#   Associate this post with one or more of your projects.
#   Simply enter your project's folder or file name without extension.
#   E.g. `projects = ["internal-project"]` references `content/project/deep-learning/index.md`.
#   Otherwise, set `projects = []`.
projects: []
publishDate: '2021-04-06T13:49:34.708101Z'
publication_types:
- '2'
abstract: ''
publication: '*Pharmacogenomics Journal*'
url_pdf: https://www.scopus.com/inward/record.uri?eid=2-s2.0-85004098313&doi=10.1038%2ftpj.2016.76&partnerID=40&md5=afed17d4a5a5c7287b868f38dc069e7b
doi: 10.1038/tpj.2016.76
---
