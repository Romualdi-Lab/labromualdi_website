---
# Documentation: https://wowchemy.com/docs/managing-content/

title: MiRNA landscape in stage i epithelial ovarian cancer defines the histotype
  specificities
subtitle: ''
summary: ''
authors:
- E. Calura
- R. Fruscio
- L. Paracchini
- E. Bignotti
- A. Ravaggi
- P. Martini
- G. Sales
- L. Beltrame
- L. Clivio
- L. Ceppi
- M. Di Marino
- I.F. Nerini
- L. Zanotti
- D. Cavalieri
- G. Cattoretti
- P. Perego
- R. Milani
- D. Katsaros
- G. Tognon
- E. Sartori
- S. Pecorelli
- C. Mangioni
- M. D'Incalci
- C. Romualdi
- S. Marchini
tags: []
categories: []
date: '2013-01-01'
lastmod: 2021-04-06T15:49:40+02:00
featured: false
draft: false

# Featured image
# To use, add an image named `featured.jpg/png` to your page's folder.
# Focal points: Smart, Center, TopLeft, Top, TopRight, Left, Right, BottomLeft, Bottom, BottomRight.
image:
  caption: ''
  focal_point: ''
  preview_only: false

# Projects (optional).
#   Associate this post with one or more of your projects.
#   Simply enter your project's folder or file name without extension.
#   E.g. `projects = ["internal-project"]` references `content/project/deep-learning/index.md`.
#   Otherwise, set `projects = []`.
projects: []
publishDate: '2021-04-06T13:49:39.868687Z'
publication_types:
- '2'
abstract: ''
publication: '*Clinical Cancer Research*'
url_pdf: https://www.scopus.com/inward/record.uri?eid=2-s2.0-84881258346&doi=10.1158%2f1078-0432.CCR-13-0360&partnerID=40&md5=0b7edf79d258450ccfd1cc84eed7363e
doi: 10.1158/1078-0432.CCR-13-0360
---
