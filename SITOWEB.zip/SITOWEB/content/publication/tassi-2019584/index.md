---
# Documentation: https://wowchemy.com/docs/managing-content/

title: FXYD5 (Dysadherin) upregulation predicts shorter survival and reveals platinum
  resistance in high-grade serous ovarian cancer patients
subtitle: ''
summary: ''
authors:
- R.A. Tassi
- A. Gambino
- L. Ardighieri
- E. Bignotti
- P. Todeschini
- C. Romani
- L. Zanotti
- M. Bugatti
- F. Borella
- D. Katsaros
- G. Tognon
- E. Sartori
- F. Odicino
- C. Romualdi
- A. Ravaggi
tags: []
categories: []
date: '2019-01-01'
lastmod: 2021-04-06T15:49:33+02:00
featured: false
draft: false

# Featured image
# To use, add an image named `featured.jpg/png` to your page's folder.
# Focal points: Smart, Center, TopLeft, Top, TopRight, Left, Right, BottomLeft, Bottom, BottomRight.
image:
  caption: ''
  focal_point: ''
  preview_only: false

# Projects (optional).
#   Associate this post with one or more of your projects.
#   Simply enter your project's folder or file name without extension.
#   E.g. `projects = ["internal-project"]` references `content/project/deep-learning/index.md`.
#   Otherwise, set `projects = []`.
projects: []
publishDate: '2021-04-06T13:49:32.841450Z'
publication_types:
- '2'
abstract: ''
publication: '*British Journal of Cancer*'
url_pdf: https://www.scopus.com/inward/record.uri?eid=2-s2.0-85071327259&doi=10.1038%2fs41416-019-0553-z&partnerID=40&md5=7deaf4d081d3e027cba62771fd1fe79a
doi: 10.1038/s41416-019-0553-z
---
