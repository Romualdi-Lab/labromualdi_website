---
# Documentation: https://wowchemy.com/docs/managing-content/

title: 'Microsatellite unstable gastrointestinal neuroendocrine carcinomas: A new
  clinicopathologic entity'
subtitle: ''
summary: ''
authors:
- N. Sahnane
- D. Furlan
- M. Monti
- C. Romualdi
- A. Vanoli
- E. Vicari
- E. Solcia
- C. Capella
- F. Sessa
- S. La Rosa
tags: []
categories: []
date: '2015-01-01'
lastmod: 2021-04-06T15:49:38+02:00
featured: false
draft: false

# Featured image
# To use, add an image named `featured.jpg/png` to your page's folder.
# Focal points: Smart, Center, TopLeft, Top, TopRight, Left, Right, BottomLeft, Bottom, BottomRight.
image:
  caption: ''
  focal_point: ''
  preview_only: false

# Projects (optional).
#   Associate this post with one or more of your projects.
#   Simply enter your project's folder or file name without extension.
#   E.g. `projects = ["internal-project"]` references `content/project/deep-learning/index.md`.
#   Otherwise, set `projects = []`.
projects: []
publishDate: '2021-04-06T13:49:38.042280Z'
publication_types:
- '2'
abstract: ''
publication: '*Endocrine-Related Cancer*'
url_pdf: https://www.scopus.com/inward/record.uri?eid=2-s2.0-84923618154&doi=10.1530%2fERC-14-0410&partnerID=40&md5=2bbf740489d88cf172fa8b3a40c05ba2
doi: 10.1530/ERC-14-0410
---
