---
# Documentation: https://wowchemy.com/docs/managing-content/

title: 'TRAIT (TRAnscript Integrated Table): A knowledgebase of human skeletal muscle
  transcripts'
subtitle: ''
summary: ''
authors:
- S. Toppo
- N. Cannata
- P. Fontana
- C. Romualdi
- P. Laveder
- E. Bertocco
- G. Lanfranchi
- G. Valle
tags: []
categories: []
date: '2003-01-01'
lastmod: 2021-04-06T15:49:50+02:00
featured: false
draft: false

# Featured image
# To use, add an image named `featured.jpg/png` to your page's folder.
# Focal points: Smart, Center, TopLeft, Top, TopRight, Left, Right, BottomLeft, Bottom, BottomRight.
image:
  caption: ''
  focal_point: ''
  preview_only: false

# Projects (optional).
#   Associate this post with one or more of your projects.
#   Simply enter your project's folder or file name without extension.
#   E.g. `projects = ["internal-project"]` references `content/project/deep-learning/index.md`.
#   Otherwise, set `projects = []`.
projects: []
publishDate: '2021-04-06T13:49:50.197531Z'
publication_types:
- '2'
abstract: ''
publication: '*Bioinformatics*'
url_pdf: https://www.scopus.com/inward/record.uri?eid=2-s2.0-0037460981&doi=10.1093%2fbioinformatics%2fbtg045&partnerID=40&md5=8eae278f3552a56a1043cd858a277faa
doi: 10.1093/bioinformatics/btg045
---
