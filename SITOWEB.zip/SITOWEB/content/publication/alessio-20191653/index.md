---
# Documentation: https://wowchemy.com/docs/managing-content/

title: Single cell analysis reveals the involvement of the long non-coding RNA Pvt1
  in the modulation of muscle atrophy and mitochondrial network
subtitle: ''
summary: ''
authors:
- E. Alessio
- L. Buson
- F. Chemello
- C. Peggion
- F. Grespi
- P. Martini
- M.L. Massimino
- B. Pacchioni
- C. Millino
- C. Romualdi
- A. Bertoli
- L. Scorrano
- G. Lanfranchi
- S. Cagnin
tags: []
categories: []
date: '2019-01-01'
lastmod: 2021-04-06T15:49:33+02:00
featured: false
draft: false

# Featured image
# To use, add an image named `featured.jpg/png` to your page's folder.
# Focal points: Smart, Center, TopLeft, Top, TopRight, Left, Right, BottomLeft, Bottom, BottomRight.
image:
  caption: ''
  focal_point: ''
  preview_only: false

# Projects (optional).
#   Associate this post with one or more of your projects.
#   Simply enter your project's folder or file name without extension.
#   E.g. `projects = ["internal-project"]` references `content/project/deep-learning/index.md`.
#   Otherwise, set `projects = []`.
projects: []
publishDate: '2021-04-06T13:49:33.485059Z'
publication_types:
- '2'
abstract: ''
publication: '*Nucleic Acids Research*'
url_pdf: https://www.scopus.com/inward/record.uri?eid=2-s2.0-85062272162&doi=10.1093%2fnar%2fgkz007&partnerID=40&md5=bb3ad97477e1425436c2b6581a0aa38f
doi: 10.1093/nar/gkz007
---
