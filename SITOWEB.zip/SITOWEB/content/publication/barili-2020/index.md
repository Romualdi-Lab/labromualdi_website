---
# Documentation: https://wowchemy.com/docs/managing-content/

title: Targeting p53 and histone methyltransferases restores exhausted CD8+ T cells
  in HCV infection
subtitle: ''
summary: ''
authors:
- V. Barili
- P. Fisicaro
- B. Montanini
- G. Acerbi
- A. Filippi
- G. Forleo
- C. Romualdi
- M. Ferracin
- F. Guerrieri
- G. Pedrazzi
- C. Boni
- M. Rossi
- A. Vecchi
- A. Penna
- A. Zecca
- C. Mori
- A. Orlandini
- E. Negri
- M. Pesci
- M. Massari
- G. Missale
- M. Levrero
- S. Ottonello
- C. Ferrari
tags: []
categories: []
date: '2020-01-01'
lastmod: 2021-04-06T15:49:31+02:00
featured: false
draft: false

# Featured image
# To use, add an image named `featured.jpg/png` to your page's folder.
# Focal points: Smart, Center, TopLeft, Top, TopRight, Left, Right, BottomLeft, Bottom, BottomRight.
image:
  caption: ''
  focal_point: ''
  preview_only: false

# Projects (optional).
#   Associate this post with one or more of your projects.
#   Simply enter your project's folder or file name without extension.
#   E.g. `projects = ["internal-project"]` references `content/project/deep-learning/index.md`.
#   Otherwise, set `projects = []`.
projects: []
publishDate: '2021-04-06T13:49:30.837117Z'
publication_types:
- '2'
abstract: ''
publication: '*Nature Communications*'
url_pdf: https://www.scopus.com/inward/record.uri?eid=2-s2.0-85078710344&doi=10.1038%2fs41467-019-14137-7&partnerID=40&md5=ad917deac0f13f3a5e2bcd83fb0c2279
doi: 10.1038/s41467-019-14137-7
---
