---
# Documentation: https://wowchemy.com/docs/managing-content/

title: 'Circulating miRNA landscape identifies miR-1246 as promising diagnostic biomarker
  in high-grade serous ovarian carcinoma: A validation across two independent cohorts'
subtitle: ''
summary: ''
authors:
- P. Todeschini
- E. Salviato
- L. Paracchini
- M. Ferracin
- M. Petrillo
- L. Zanotti
- G. Tognon
- A. Gambino
- E. Calura
- G. Caratti
- P. Martini
- L. Beltrame
- L. Maragoni
- D. Gallo
- F.E. Odicino
- E. Sartori
- G. Scambia
- M. Negrini
- A. Ravaggi
- M. D'Incalci
- S. Marchini
- E. Bignotti
- C. Romualdi
tags: []
categories: []
date: '2017-01-01'
lastmod: 2021-04-06T15:49:35+02:00
featured: false
draft: false

# Featured image
# To use, add an image named `featured.jpg/png` to your page's folder.
# Focal points: Smart, Center, TopLeft, Top, TopRight, Left, Right, BottomLeft, Bottom, BottomRight.
image:
  caption: ''
  focal_point: ''
  preview_only: false

# Projects (optional).
#   Associate this post with one or more of your projects.
#   Simply enter your project's folder or file name without extension.
#   E.g. `projects = ["internal-project"]` references `content/project/deep-learning/index.md`.
#   Otherwise, set `projects = []`.
projects: []
publishDate: '2021-04-06T13:49:35.448651Z'
publication_types:
- '2'
abstract: ''
publication: '*Cancer Letters*'
url_pdf: https://www.scopus.com/inward/record.uri?eid=2-s2.0-85007597335&doi=10.1016%2fj.canlet.2016.12.017&partnerID=40&md5=b0581d5c7372e1d2c45db4463528adba
doi: 10.1016/j.canlet.2016.12.017
---
