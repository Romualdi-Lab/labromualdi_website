---
# Documentation: https://wowchemy.com/docs/managing-content/

title: Expression profiling characterization of laminin α-2 positive MDC
subtitle: ''
summary: ''
authors:
- C. Millino
- M. Bellin
- M. Fanin
- C. Romualdi
- E. Pegoraro
- C. Angelini
- G. Lanfranchi
tags: []
categories: []
date: '2006-01-01'
lastmod: 2021-04-06T15:49:47+02:00
featured: false
draft: false

# Featured image
# To use, add an image named `featured.jpg/png` to your page's folder.
# Focal points: Smart, Center, TopLeft, Top, TopRight, Left, Right, BottomLeft, Bottom, BottomRight.
image:
  caption: ''
  focal_point: ''
  preview_only: false

# Projects (optional).
#   Associate this post with one or more of your projects.
#   Simply enter your project's folder or file name without extension.
#   E.g. `projects = ["internal-project"]` references `content/project/deep-learning/index.md`.
#   Otherwise, set `projects = []`.
projects: []
publishDate: '2021-04-06T13:49:47.382177Z'
publication_types:
- '2'
abstract: ''
publication: '*Biochemical and Biophysical Research Communications*'
url_pdf: https://www.scopus.com/inward/record.uri?eid=2-s2.0-33749354868&doi=10.1016%2fj.bbrc.2006.09.063&partnerID=40&md5=55d494b32f0b63a68c41e05a8cb614a2
doi: 10.1016/j.bbrc.2006.09.063
---
