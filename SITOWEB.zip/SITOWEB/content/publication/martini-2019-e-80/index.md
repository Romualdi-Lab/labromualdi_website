---
# Documentation: https://wowchemy.com/docs/managing-content/

title: 'MOSClip: multi-omic and survival pathway analysis for the identification of survival associated gene and modules'
subtitle: ''
summary: ''
authors:
- P. Martini
- M. Chiogna
- E. Calura
- C. Romualdi
tags: []
categories: []
date: '2019-01-01'
lastmod: 2021-04-06T15:49:33+02:00
featured: true
draft: false

# Featured image
# To use, add an image named `featured.jpg/png` to your page's folder.
# Focal points: Smart, Center, TopLeft, Top, TopRight, Left, Right, BottomLeft, Bottom, BottomRight.
image:
  caption: ''
  focal_point: 'Smart'
  preview_only: true

# Projects (optional).
#   Associate this post with one or more of your projects.
#   Simply enter your project's folder or file name without extension.
#   E.g. `projects = ["internal-project"]` references `content/project/deep-learning/index.md`.
#   Otherwise, set `projects = []`.
projects: []
publishDate: '2021-04-06T13:49:33.022721Z'
publication_types:
- '2'
abstract: ''
publication: '*Nucleic acids research*'
url_pdf: https://www.scopus.com/inward/record.uri?eid=2-s2.0-85071700509&doi=10.1093%2fnar%2fgkz324&partnerID=40&md5=f25384928b3aaad1e6f03a98d2b705da
doi: 10.1093/nar/gkz324
---
