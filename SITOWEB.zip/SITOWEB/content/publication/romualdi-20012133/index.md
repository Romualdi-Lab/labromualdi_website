---
# Documentation: https://wowchemy.com/docs/managing-content/

title: 'Detecting differentially expressed genes in multiple tag sampling experiments:
  Comparative evaluation of statistical tests'
subtitle: ''
summary: ''
authors:
- C. Romualdi
- S. Bortoluzzi
- G.A. Danieli
tags: []
categories: []
date: '2001-01-01'
lastmod: 2021-04-06T15:49:51+02:00
featured: false
draft: false

# Featured image
# To use, add an image named `featured.jpg/png` to your page's folder.
# Focal points: Smart, Center, TopLeft, Top, TopRight, Left, Right, BottomLeft, Bottom, BottomRight.
image:
  caption: ''
  focal_point: ''
  preview_only: false

# Projects (optional).
#   Associate this post with one or more of your projects.
#   Simply enter your project's folder or file name without extension.
#   E.g. `projects = ["internal-project"]` references `content/project/deep-learning/index.md`.
#   Otherwise, set `projects = []`.
projects: []
publishDate: '2021-04-06T13:49:51.641644Z'
publication_types:
- '2'
abstract: ''
publication: '*Human Molecular Genetics*'
url_pdf: https://www.scopus.com/inward/record.uri?eid=2-s2.0-0034772104&doi=10.1093%2fhmg%2f10.19.2133&partnerID=40&md5=00223686d98fa5a80f9a53bc81a537ec
doi: 10.1093/hmg/10.19.2133
---
