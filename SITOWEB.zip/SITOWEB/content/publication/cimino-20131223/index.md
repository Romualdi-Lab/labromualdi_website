---
# Documentation: https://wowchemy.com/docs/managing-content/

title: miR148b is a major coordinator of breast cancer progression in a relapse-associated
  microRNA signature by targeting ITGA5, ROCK1, PIK3CA, NRAS, and CSF1
subtitle: ''
summary: ''
authors:
- D. Cimino
- C. De Pittà
- F. Orso
- M. Zampini
- S. Casara
- E. Penna
- E. Quaglino
- M. Forni
- C. Damasco
- E. Pinatel
- R. Ponzone
- C. Romualdi
- C. Brisken
- M. De Bortoli
- N. Biglia
- P. Provero
- G. Lanfranchi
- D. Taverna
tags: []
categories: []
date: '2013-01-01'
lastmod: 2021-04-06T15:49:40+02:00
featured: false
draft: false

# Featured image
# To use, add an image named `featured.jpg/png` to your page's folder.
# Focal points: Smart, Center, TopLeft, Top, TopRight, Left, Right, BottomLeft, Bottom, BottomRight.
image:
  caption: ''
  focal_point: ''
  preview_only: false

# Projects (optional).
#   Associate this post with one or more of your projects.
#   Simply enter your project's folder or file name without extension.
#   E.g. `projects = ["internal-project"]` references `content/project/deep-learning/index.md`.
#   Otherwise, set `projects = []`.
projects: []
publishDate: '2021-04-06T13:49:40.398663Z'
publication_types:
- '2'
abstract: ''
publication: '*FASEB Journal*'
url_pdf: https://www.scopus.com/inward/record.uri?eid=2-s2.0-84874626235&doi=10.1096%2ffj.12-214692&partnerID=40&md5=bf634b7884d33439074e5a9fa4933a01
doi: 10.1096/fj.12-214692
---
