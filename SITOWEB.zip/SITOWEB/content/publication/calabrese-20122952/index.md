---
# Documentation: https://wowchemy.com/docs/managing-content/

title: Cortical lesion load associates with progression of disability in multiple
  sclerosis
subtitle: ''
summary: ''
authors:
- M. Calabrese
- V. Poretto
- A. Favaretto
- S. Alessio
- V. Bernardi
- C. Romualdi
- F. Rinaldi
- P. Perini
- P. Gallo
tags: []
categories: []
date: '2012-01-01'
lastmod: 2021-04-06T15:49:42+02:00
featured: false
draft: false

# Featured image
# To use, add an image named `featured.jpg/png` to your page's folder.
# Focal points: Smart, Center, TopLeft, Top, TopRight, Left, Right, BottomLeft, Bottom, BottomRight.
image:
  caption: ''
  focal_point: ''
  preview_only: false

# Projects (optional).
#   Associate this post with one or more of your projects.
#   Simply enter your project's folder or file name without extension.
#   E.g. `projects = ["internal-project"]` references `content/project/deep-learning/index.md`.
#   Otherwise, set `projects = []`.
projects: []
publishDate: '2021-04-06T13:49:41.926617Z'
publication_types:
- '2'
abstract: ''
publication: '*Brain*'
url_pdf: https://www.scopus.com/inward/record.uri?eid=2-s2.0-84867712909&doi=10.1093%2fbrain%2faws246&partnerID=40&md5=f097fb7ae0f8d32a4d875d9a6ae449e5
doi: 10.1093/brain/aws246
---
