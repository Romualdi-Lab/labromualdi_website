---
# Documentation: https://wowchemy.com/docs/managing-content/

title: 'KrillDB: A de novo transcriptome database for the Antarctic krill (Euphausia
  superba)'
subtitle: ''
summary: ''
authors:
- G. Sales
- B.E. Deagle
- E. Calura
- P. Martini
- A. Biscontin
- C. De Pittà
- S. Kawaguchi
- C. Romualdi
- B. Meyer
- R. Costa
- S. Jarman
tags: []
categories: []
date: '2017-01-01'
lastmod: 2021-04-06T15:49:35+02:00
featured: false
draft: false

# Featured image
# To use, add an image named `featured.jpg/png` to your page's folder.
# Focal points: Smart, Center, TopLeft, Top, TopRight, Left, Right, BottomLeft, Bottom, BottomRight.
image:
  caption: ''
  focal_point: ''
  preview_only: false

# Projects (optional).
#   Associate this post with one or more of your projects.
#   Simply enter your project's folder or file name without extension.
#   E.g. `projects = ["internal-project"]` references `content/project/deep-learning/index.md`.
#   Otherwise, set `projects = []`.
projects: []
publishDate: '2021-04-06T13:49:35.663772Z'
publication_types:
- '2'
abstract: ''
publication: '*PLoS ONE*'
url_pdf: https://www.scopus.com/inward/record.uri?eid=2-s2.0-85012217334&doi=10.1371%2fjournal.pone.0171908&partnerID=40&md5=06a3adef66aeaf0d77dc1b9629b6d440
doi: 10.1371/journal.pone.0171908
---
