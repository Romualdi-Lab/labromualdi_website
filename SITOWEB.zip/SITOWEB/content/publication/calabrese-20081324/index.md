---
# Documentation: https://wowchemy.com/docs/managing-content/

title: Morphology and evolution of cortical lesions in multiple sclerosis. A longitudinal
  MRI study
subtitle: ''
summary: ''
authors:
- M. Calabrese
- M. Filippi
- M. Rovaris
- I. Mattisi
- V. Bernardi
- M. Atzori
- A. Favaretto
- L. Barachino
- L. Rinaldi
- C. Romualdi
- P. Perini
- P. Gallo
tags: []
categories: []
date: '2008-01-01'
lastmod: 2021-04-06T15:49:46+02:00
featured: false
draft: false

# Featured image
# To use, add an image named `featured.jpg/png` to your page's folder.
# Focal points: Smart, Center, TopLeft, Top, TopRight, Left, Right, BottomLeft, Bottom, BottomRight.
image:
  caption: ''
  focal_point: ''
  preview_only: false

# Projects (optional).
#   Associate this post with one or more of your projects.
#   Simply enter your project's folder or file name without extension.
#   E.g. `projects = ["internal-project"]` references `content/project/deep-learning/index.md`.
#   Otherwise, set `projects = []`.
projects: []
publishDate: '2021-04-06T13:49:45.963883Z'
publication_types:
- '2'
abstract: ''
publication: '*NeuroImage*'
url_pdf: https://www.scopus.com/inward/record.uri?eid=2-s2.0-55349123227&doi=10.1016%2fj.neuroimage.2008.06.028&partnerID=40&md5=84a7244a17e24f248b84622a81e14f82
doi: 10.1016/j.neuroimage.2008.06.028
---
