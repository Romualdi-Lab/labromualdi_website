---
# Documentation: https://wowchemy.com/docs/managing-content/

title: Resistance to platinum-based chemotherapy is associated with epithelial to
  mesenchymal transition in epithelial ovarian cancer
subtitle: ''
summary: ''
authors:
- S. Marchini
- R. Fruscio
- L. Clivio
- L. Beltrame
- L. Porcu
- I.F. Nerini
- D. Cavalieri
- G. Chiorino
- G. Cattoretti
- C. Mangioni
- R. Milani
- V. Torri
- C. Romualdi
- A. Zambelli
- M. Romano
- M. Signorelli
- S.D. Giandomenico
- M. D'Incalci
tags: []
categories: []
date: '2013-01-01'
lastmod: 2021-04-06T15:49:41+02:00
featured: false
draft: false

# Featured image
# To use, add an image named `featured.jpg/png` to your page's folder.
# Focal points: Smart, Center, TopLeft, Top, TopRight, Left, Right, BottomLeft, Bottom, BottomRight.
image:
  caption: ''
  focal_point: ''
  preview_only: false

# Projects (optional).
#   Associate this post with one or more of your projects.
#   Simply enter your project's folder or file name without extension.
#   E.g. `projects = ["internal-project"]` references `content/project/deep-learning/index.md`.
#   Otherwise, set `projects = []`.
projects: []
publishDate: '2021-04-06T13:49:41.045776Z'
publication_types:
- '2'
abstract: ''
publication: '*European Journal of Cancer*'
url_pdf: https://www.scopus.com/inward/record.uri?eid=2-s2.0-84872114095&doi=10.1016%2fj.ejca.2012.06.026&partnerID=40&md5=112506fc829efd9e3b41251f91847d93
doi: 10.1016/j.ejca.2012.06.026
---
