---
# Documentation: https://wowchemy.com/docs/managing-content/

title: 'RAP: A new computer program for de novo identification of repeated sequences
  in whole genomes'
subtitle: ''
summary: ''
authors:
- D. Campagna
- C. Romualdi
- N. Vitulo
- M. Del Favero
- M. Lexa
- N. Cannata
- G. Valle
tags: []
categories: []
date: '2005-01-01'
lastmod: 2021-04-06T15:49:49+02:00
featured: false
draft: false

# Featured image
# To use, add an image named `featured.jpg/png` to your page's folder.
# Focal points: Smart, Center, TopLeft, Top, TopRight, Left, Right, BottomLeft, Bottom, BottomRight.
image:
  caption: ''
  focal_point: ''
  preview_only: false

# Projects (optional).
#   Associate this post with one or more of your projects.
#   Simply enter your project's folder or file name without extension.
#   E.g. `projects = ["internal-project"]` references `content/project/deep-learning/index.md`.
#   Otherwise, set `projects = []`.
projects: []
publishDate: '2021-04-06T13:49:49.384243Z'
publication_types:
- '2'
abstract: ''
publication: '*Bioinformatics*'
url_pdf: https://www.scopus.com/inward/record.uri?eid=2-s2.0-15844389857&doi=10.1093%2fbioinformatics%2fbti039&partnerID=40&md5=45a2a8be426e48fe7810c67bbc94ef0f
doi: 10.1093/bioinformatics/bti039
---
