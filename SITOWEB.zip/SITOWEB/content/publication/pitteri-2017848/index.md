---
# Documentation: https://wowchemy.com/docs/managing-content/

title: 'Cognitive impairment predicts disability progression and cortical thinning
  in MS: An 8-year study'
subtitle: ''
summary: ''
authors:
- M. Pitteri
- C. Romualdi
- R. Magliozzi
- S. Monaco
- M. Calabrese
tags: []
categories: []
date: '2017-01-01'
lastmod: 2021-04-06T15:49:35+02:00
featured: false
draft: false

# Featured image
# To use, add an image named `featured.jpg/png` to your page's folder.
# Focal points: Smart, Center, TopLeft, Top, TopRight, Left, Right, BottomLeft, Bottom, BottomRight.
image:
  caption: ''
  focal_point: ''
  preview_only: false

# Projects (optional).
#   Associate this post with one or more of your projects.
#   Simply enter your project's folder or file name without extension.
#   E.g. `projects = ["internal-project"]` references `content/project/deep-learning/index.md`.
#   Otherwise, set `projects = []`.
projects: []
publishDate: '2021-04-06T13:49:35.231886Z'
publication_types:
- '2'
abstract: ''
publication: '*Multiple Sclerosis*'
url_pdf: https://www.scopus.com/inward/record.uri?eid=2-s2.0-85019029833&doi=10.1177%2f1352458516665496&partnerID=40&md5=4f12ae57a0c58af7ed1f015b67c83c27
doi: 10.1177/1352458516665496
---
