---
# Documentation: https://wowchemy.com/docs/managing-content/

title: Austenite grain size model for the coarse grain heat affected zone in line
  pipe steels
subtitle: ''
summary: ''
authors:
- N. Romualdi
- M. Militzer
- W. Poole
- L. Collins
- R. Lazor
tags: []
categories: []
date: '2020-01-01'
lastmod: 2021-04-06T15:49:32+02:00
featured: false
draft: false

# Featured image
# To use, add an image named `featured.jpg/png` to your page's folder.
# Focal points: Smart, Center, TopLeft, Top, TopRight, Left, Right, BottomLeft, Bottom, BottomRight.
image:
  caption: ''
  focal_point: ''
  preview_only: false

# Projects (optional).
#   Associate this post with one or more of your projects.
#   Simply enter your project's folder or file name without extension.
#   E.g. `projects = ["internal-project"]` references `content/project/deep-learning/index.md`.
#   Otherwise, set `projects = []`.
projects: []
publishDate: '2021-04-06T13:49:32.161055Z'
publication_types:
- '1'
abstract: ''
publication: '*Proceedings of the Biennial International Pipeline Conference, IPC*'
url_pdf: https://www.scopus.com/inward/record.uri?eid=2-s2.0-85099780364&doi=10.1115%2fIPC2020-9687&partnerID=40&md5=df81b083854a8900c3e8ff07f25ab763
doi: 10.1115/IPC2020-9687
---
