---
# Documentation: https://wowchemy.com/docs/managing-content/

title: Development and validation of a gene expression oligo microarray for the gilthead
  sea bream (Sparus aurata)
subtitle: ''
summary: ''
authors:
- S. Ferraresso
- N. Vitulo
- A.N. Mininni
- C. Romualdi
- B. Cardazzo
- E. Negrisolo
- R. Reinhardt
- A.V.M. Canario
- T. Patarnello
- L. Bargelloni
tags: []
categories: []
date: '2008-01-01'
lastmod: 2021-04-06T15:49:45+02:00
featured: false
draft: false

# Featured image
# To use, add an image named `featured.jpg/png` to your page's folder.
# Focal points: Smart, Center, TopLeft, Top, TopRight, Left, Right, BottomLeft, Bottom, BottomRight.
image:
  caption: ''
  focal_point: ''
  preview_only: false

# Projects (optional).
#   Associate this post with one or more of your projects.
#   Simply enter your project's folder or file name without extension.
#   E.g. `projects = ["internal-project"]` references `content/project/deep-learning/index.md`.
#   Otherwise, set `projects = []`.
projects: []
publishDate: '2021-04-06T13:49:45.803760Z'
publication_types:
- '2'
abstract: ''
publication: '*BMC Genomics*'
url_pdf: https://www.scopus.com/inward/record.uri?eid=2-s2.0-61649122339&doi=10.1186%2f1471-2164-9-580&partnerID=40&md5=3ab284a3664537fe5fe239af6b406295
doi: 10.1186/1471-2164-9-580
---
