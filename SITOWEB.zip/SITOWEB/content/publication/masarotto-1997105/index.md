---
# Documentation: https://wowchemy.com/docs/managing-content/

title: 'Probability of conception on different days of the menstrual cycle: An ongoing
  exercise'
subtitle: ''
summary: ''
authors:
- G. Masarotto
- C. Romualdi
tags: []
categories: []
date: '1997-01-01'
lastmod: 2021-04-06T15:49:52+02:00
featured: false
draft: false

# Featured image
# To use, add an image named `featured.jpg/png` to your page's folder.
# Focal points: Smart, Center, TopLeft, Top, TopRight, Left, Right, BottomLeft, Bottom, BottomRight.
image:
  caption: ''
  focal_point: ''
  preview_only: false

# Projects (optional).
#   Associate this post with one or more of your projects.
#   Simply enter your project's folder or file name without extension.
#   E.g. `projects = ["internal-project"]` references `content/project/deep-learning/index.md`.
#   Otherwise, set `projects = []`.
projects: []
publishDate: '2021-04-06T13:49:52.176028Z'
publication_types:
- '2'
abstract: ''
publication: '*Advances in Contraception*'
url_pdf: https://www.scopus.com/inward/record.uri?eid=2-s2.0-0030800555&doi=10.1023%2fA%3a1006583300746&partnerID=40&md5=ff9495d5c1b5e9971ac6be1b2a5a460d
doi: 10.1023/A:1006583300746
---
