---
# Documentation: https://wowchemy.com/docs/managing-content/

title: Pharmacogenetic score predicts overall survival, progression-free survival
  and platinum sensitivity in ovarian cancer
subtitle: ''
summary: ''
authors:
- S. Gagno
- M. Bartoletti
- C. Romualdi
- E. Poletto
- S. Scalone
- R. Sorio
- M. Zanchetta
- E. De Mattia
- R. Roncato
- E. Cecchin
- G. Giorda
- G. Toffoli
tags: []
categories: []
date: '2020-01-01'
lastmod: 2021-04-06T15:49:31+02:00
featured: false
draft: false

# Featured image
# To use, add an image named `featured.jpg/png` to your page's folder.
# Focal points: Smart, Center, TopLeft, Top, TopRight, Left, Right, BottomLeft, Bottom, BottomRight.
image:
  caption: ''
  focal_point: ''
  preview_only: false

# Projects (optional).
#   Associate this post with one or more of your projects.
#   Simply enter your project's folder or file name without extension.
#   E.g. `projects = ["internal-project"]` references `content/project/deep-learning/index.md`.
#   Otherwise, set `projects = []`.
projects: []
publishDate: '2021-04-06T13:49:31.455323Z'
publication_types:
- '2'
abstract: ''
publication: '*Pharmacogenomics*'
url_pdf: https://www.scopus.com/inward/record.uri?eid=2-s2.0-85091654967&doi=10.2217%2fpgs-2020-0049&partnerID=40&md5=37a20fa451eea4ad6d9b47f2505bfe74
doi: 10.2217/pgs-2020-0049
---
