+++
title = "NewWave: A scalable R/Bioconductor package for the dimensionality reduction and batch effect removal of single-cell RNA-seq data"
date = "2022-01-01"
authors = ["F. Agostinis", "C. Romualdi", "G. Sales", "D. Risso"]
publication_types = ["2"]
publication = "Bioinformatics, (38), 9, _pp. 2648-2650_, https://doi.org/10.1093/bioinformatics/btac149"
publication_short = "Bioinformatics, (38), 9, _pp. 2648-2650_, https://doi.org/10.1093/bioinformatics/btac149"
abstract = ""
abstract_short = ""
image_preview = ""
selected = false
projects = []
tags = []
url_pdf = ""
url_preprint = ""
url_code = ""
url_dataset = ""
url_project = ""
url_slides = ""
url_video = ""
url_poster = ""
url_source = ""
math = true
highlight = true
[header]
image = ""
caption = ""
+++
