---
# Documentation: https://wowchemy.com/docs/managing-content/

title: Genome-wide study of salivary miRNAs identifies miR-423-5p as promising diagnostic
  and prognostic biomarker in oral squamous cell carcinoma
subtitle: ''
summary: ''
authors:
- C. Romani
- E. Salviato
- A. Paderno
- L. Zanotti
- A. Ravaggi
- A. Deganello
- G. Berretti
- T. Gualtieri
- S. Marchini
- M. D’Incalci
- D. Mattavelli
- C. Piazza
- P. Bossi
- C. Romualdi
- P. Nicolai
- E. Bignotti
tags: []
categories: []
date: '2021-01-01'
lastmod: 2021-04-06T15:49:30+02:00
featured: false
draft: false

# Featured image
# To use, add an image named `featured.jpg/png` to your page's folder.
# Focal points: Smart, Center, TopLeft, Top, TopRight, Left, Right, BottomLeft, Bottom, BottomRight.
image:
  caption: ''
  focal_point: ''
  preview_only: false

# Projects (optional).
#   Associate this post with one or more of your projects.
#   Simply enter your project's folder or file name without extension.
#   E.g. `projects = ["internal-project"]` references `content/project/deep-learning/index.md`.
#   Otherwise, set `projects = []`.
projects: []
publishDate: '2021-04-06T13:49:30.687066Z'
publication_types:
- '2'
abstract: ''
publication: '*Theranostics*'
url_pdf: https://www.scopus.com/inward/record.uri?eid=2-s2.0-85100127368&doi=10.7150%2fTHNO.45157&partnerID=40&md5=fc2c06204e1cf1437b014daea5c4a661
doi: 10.7150/THNO.45157
---
