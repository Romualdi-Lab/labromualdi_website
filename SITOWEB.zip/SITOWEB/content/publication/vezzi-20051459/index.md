---
# Documentation: https://wowchemy.com/docs/managing-content/

title: 'Life at depth: Photobacterium profundum genome sequence and expression analysis'
subtitle: ''
summary: ''
authors:
- A. Vezzi
- S. Campanaro
- M. D'Angelo
- F. Simonato
- N. Vitulo
- F.M. Lauro
- A. Cestaro
- G. Malacrida
- B. Simionati
- N. Cannata
- C. Romualdi
- D.H. Bartlett
- G. Valle
tags: []
categories: []
date: '2005-01-01'
lastmod: 2021-04-06T15:49:49+02:00
featured: false
draft: false

# Featured image
# To use, add an image named `featured.jpg/png` to your page's folder.
# Focal points: Smart, Center, TopLeft, Top, TopRight, Left, Right, BottomLeft, Bottom, BottomRight.
image:
  caption: ''
  focal_point: ''
  preview_only: false

# Projects (optional).
#   Associate this post with one or more of your projects.
#   Simply enter your project's folder or file name without extension.
#   E.g. `projects = ["internal-project"]` references `content/project/deep-learning/index.md`.
#   Otherwise, set `projects = []`.
projects: []
publishDate: '2021-04-06T13:49:49.234385Z'
publication_types:
- '2'
abstract: ''
publication: '*Science*'
url_pdf: https://www.scopus.com/inward/record.uri?eid=2-s2.0-20044393188&doi=10.1126%2fscience.1103341&partnerID=40&md5=cbdeb8e9aa2c7d86e3dbde1c56c2e320
doi: 10.1126/science.1103341
---
