---
# Documentation: https://wowchemy.com/docs/managing-content/

title: ACUTE ABDOMEN IN CHILDHOOD. [ADDOME ACUTO NELL'INFANZIA.]
subtitle: ''
summary: ''
authors:
- P. ROMUALDI
- C. ROMUALDI
- F. BERGAMI
tags: []
categories: []
date: '1964-01-01'
lastmod: 2021-04-06T15:49:52+02:00
featured: false
draft: false

# Featured image
# To use, add an image named `featured.jpg/png` to your page's folder.
# Focal points: Smart, Center, TopLeft, Top, TopRight, Left, Right, BottomLeft, Bottom, BottomRight.
image:
  caption: ''
  focal_point: ''
  preview_only: false

# Projects (optional).
#   Associate this post with one or more of your projects.
#   Simply enter your project's folder or file name without extension.
#   E.g. `projects = ["internal-project"]` references `content/project/deep-learning/index.md`.
#   Otherwise, set `projects = []`.
projects: []
publishDate: '2021-04-06T13:49:52.537783Z'
publication_types:
- '2'
abstract: ''
publication: '*Il Lattante*'
url_pdf: https://www.scopus.com/inward/record.uri?eid=2-s2.0-76549167217&partnerID=40&md5=d7e63489aa11bc408552e097b222d680
---
