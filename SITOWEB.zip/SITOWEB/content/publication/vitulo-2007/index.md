---
# Documentation: https://wowchemy.com/docs/managing-content/

title: A global gene evolution analysis on Vibrionaceae family using phylogenetic
  profile
subtitle: ''
summary: ''
authors:
- N. Vitulo
- A. Vezzi
- C. Romualdi
- S. Campanaro
- G. Valle
tags: []
categories: []
date: '2007-01-01'
lastmod: 2021-04-06T15:49:46+02:00
featured: false
draft: false

# Featured image
# To use, add an image named `featured.jpg/png` to your page's folder.
# Focal points: Smart, Center, TopLeft, Top, TopRight, Left, Right, BottomLeft, Bottom, BottomRight.
image:
  caption: ''
  focal_point: ''
  preview_only: false

# Projects (optional).
#   Associate this post with one or more of your projects.
#   Simply enter your project's folder or file name without extension.
#   E.g. `projects = ["internal-project"]` references `content/project/deep-learning/index.md`.
#   Otherwise, set `projects = []`.
projects: []
publishDate: '2021-04-06T13:49:46.827825Z'
publication_types:
- '2'
abstract: ''
publication: '*BMC Bioinformatics*'
url_pdf: https://www.scopus.com/inward/record.uri?eid=2-s2.0-34248156125&doi=10.1186%2f1471-2105-8-S1-S23&partnerID=40&md5=e8122d7ddbeb8a261b79b695a0013ff8
doi: 10.1186/1471-2105-8-S1-S23
---
