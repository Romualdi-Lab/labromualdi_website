---
# Documentation: https://wowchemy.com/docs/managing-content/

title: 'The self-morningness/eveningness (Self-ME): An extremely concise and totally
  subjective assessment of diurnal preference'
subtitle: ''
summary: ''
authors:
- M. Turco
- M. Corrias
- F. Chiaromanni
- M. Bano
- M. Salamanca
- L. Caccin
- C. Merkel
- P. Amodio
- C. Romualdi
- C. De Pittà
- R. Costa
- S. Montagnese
tags: []
categories: []
date: '2015-01-01'
lastmod: 2021-04-06T15:49:38+02:00
featured: false
draft: false

# Featured image
# To use, add an image named `featured.jpg/png` to your page's folder.
# Focal points: Smart, Center, TopLeft, Top, TopRight, Left, Right, BottomLeft, Bottom, BottomRight.
image:
  caption: ''
  focal_point: ''
  preview_only: false

# Projects (optional).
#   Associate this post with one or more of your projects.
#   Simply enter your project's folder or file name without extension.
#   E.g. `projects = ["internal-project"]` references `content/project/deep-learning/index.md`.
#   Otherwise, set `projects = []`.
projects: []
publishDate: '2021-04-06T13:49:38.398110Z'
publication_types:
- '2'
abstract: ''
publication: '*Chronobiology International*'
url_pdf: https://www.scopus.com/inward/record.uri?eid=2-s2.0-84947943728&doi=10.3109%2f07420528.2015.1078807&partnerID=40&md5=5dc01dc4d7f603d4ffcb2f3541b6df91
doi: 10.3109/07420528.2015.1078807
---
