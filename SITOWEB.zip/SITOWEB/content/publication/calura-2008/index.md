---
# Documentation: https://wowchemy.com/docs/managing-content/

title: 'Meta-analysis of expression signatures of muscle atrophy: Gene interaction
  networks in early and late stages'
subtitle: ''
summary: ''
authors:
- E. Calura
- S. Cagnin
- A. Raffaello
- P. Laveder
- G. Lanfranchi
- C. Romualdi
tags: []
categories: []
date: '2008-01-01'
lastmod: 2021-04-06T15:49:45+02:00
featured: false
draft: false

# Featured image
# To use, add an image named `featured.jpg/png` to your page's folder.
# Focal points: Smart, Center, TopLeft, Top, TopRight, Left, Right, BottomLeft, Bottom, BottomRight.
image:
  caption: ''
  focal_point: ''
  preview_only: false

# Projects (optional).
#   Associate this post with one or more of your projects.
#   Simply enter your project's folder or file name without extension.
#   E.g. `projects = ["internal-project"]` references `content/project/deep-learning/index.md`.
#   Otherwise, set `projects = []`.
projects: []
publishDate: '2021-04-06T13:49:45.663421Z'
publication_types:
- '2'
abstract: ''
publication: '*BMC Genomics*'
url_pdf: https://www.scopus.com/inward/record.uri?eid=2-s2.0-60549085643&doi=10.1186%2f1471-2164-9-630&partnerID=40&md5=94d1eea6832094d244a22765fc283b2d
doi: 10.1186/1471-2164-9-630
---
