---
# Documentation: https://wowchemy.com/docs/managing-content/

title: Transcriptomic Analysis of Single Isolated Myofibers Identifies miR-27a-3p
  and miR-142-3p as Regulators of Metabolism in Skeletal Muscle
subtitle: ''
summary: ''
authors:
- F. Chemello
- F. Grespi
- A. Zulian
- P. Cancellara
- E. Hebert-Chatelain
- P. Martini
- C. Bean
- E. Alessio
- L. Buson
- M. Bazzega
- A. Armani
- M. Sandri
- R. Ferrazza
- P. Laveder
- G. Guella
- C. Reggiani
- C. Romualdi
- P. Bernardi
- L. Scorrano
- S. Cagnin
- G. Lanfranchi
tags: []
categories: []
date: '2019-01-01'
lastmod: 2021-04-06T15:49:33+02:00
featured: false
draft: false

# Featured image
# To use, add an image named `featured.jpg/png` to your page's folder.
# Focal points: Smart, Center, TopLeft, Top, TopRight, Left, Right, BottomLeft, Bottom, BottomRight.
image:
  caption: ''
  focal_point: ''
  preview_only: false

# Projects (optional).
#   Associate this post with one or more of your projects.
#   Simply enter your project's folder or file name without extension.
#   E.g. `projects = ["internal-project"]` references `content/project/deep-learning/index.md`.
#   Otherwise, set `projects = []`.
projects: []
publishDate: '2021-04-06T13:49:33.357695Z'
publication_types:
- '2'
abstract: ''
publication: '*Cell Reports*'
url_pdf: https://www.scopus.com/inward/record.uri?eid=2-s2.0-85063063006&doi=10.1016%2fj.celrep.2019.02.105&partnerID=40&md5=ad2d6e610e327fee7815d6664ed14f32
doi: 10.1016/j.celrep.2019.02.105
---
