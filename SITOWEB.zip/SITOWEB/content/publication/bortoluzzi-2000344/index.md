---
# Documentation: https://wowchemy.com/docs/managing-content/

title: The human adult skeletal muscle transcriptional profile reconstructed by a
  novel computational approach
subtitle: ''
summary: ''
authors:
- S. Bortoluzzi
- F. D'Alessi
- C. Romualdi
- G.A. Danieli
tags: []
categories: []
date: '2000-01-01'
lastmod: 2021-04-06T15:49:52+02:00
featured: false
draft: false

# Featured image
# To use, add an image named `featured.jpg/png` to your page's folder.
# Focal points: Smart, Center, TopLeft, Top, TopRight, Left, Right, BottomLeft, Bottom, BottomRight.
image:
  caption: ''
  focal_point: ''
  preview_only: false

# Projects (optional).
#   Associate this post with one or more of your projects.
#   Simply enter your project's folder or file name without extension.
#   E.g. `projects = ["internal-project"]` references `content/project/deep-learning/index.md`.
#   Otherwise, set `projects = []`.
projects: []
publishDate: '2021-04-06T13:49:52.035826Z'
publication_types:
- '2'
abstract: ''
publication: '*Genome Research*'
url_pdf: https://www.scopus.com/inward/record.uri?eid=2-s2.0-0034065044&doi=10.1101%2fgr.10.3.344&partnerID=40&md5=3c4d97888d989e9d21b82cedcc504d8f
doi: 10.1101/gr.10.3.344
---
