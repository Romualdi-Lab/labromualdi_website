---
# Documentation: https://wowchemy.com/docs/managing-content/

title: Similarity Measures Based on the Overlap of Ranked Genes Are Effective for
  Comparison and Classification of Microarray Data
subtitle: ''
summary: ''
authors:
- F. Serra
- C. Romualdi
- F. Fogolari
tags: []
categories: []
date: '2016-01-01'
lastmod: 2021-04-06T15:49:36+02:00
featured: false
draft: false

# Featured image
# To use, add an image named `featured.jpg/png` to your page's folder.
# Focal points: Smart, Center, TopLeft, Top, TopRight, Left, Right, BottomLeft, Bottom, BottomRight.
image:
  caption: ''
  focal_point: ''
  preview_only: false

# Projects (optional).
#   Associate this post with one or more of your projects.
#   Simply enter your project's folder or file name without extension.
#   E.g. `projects = ["internal-project"]` references `content/project/deep-learning/index.md`.
#   Otherwise, set `projects = []`.
projects: []
publishDate: '2021-04-06T13:49:36.527584Z'
publication_types:
- '2'
abstract: ''
publication: '*Journal of Computational Biology*'
url_pdf: https://www.scopus.com/inward/record.uri?eid=2-s2.0-84976536613&doi=10.1089%2fcmb.2015.0057&partnerID=40&md5=c0875d78f45674c0bd23b64727e0762e
doi: 10.1089/cmb.2015.0057
---
