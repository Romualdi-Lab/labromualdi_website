---
# Documentation: https://wowchemy.com/docs/managing-content/

title: 'MAGIA2: From miRNA and genes expression data integrative analysis to microRNA-transcription
  factor mixed regulatory circuits (2012 update)'
subtitle: ''
summary: ''
authors:
- A. Bisognin
- G. Sales
- A. Coppe
- S. Bortoluzzi
- C. Romualdi
tags: []
categories: []
date: '2012-01-01'
lastmod: 2021-04-06T15:49:41+02:00
featured: false
draft: false

# Featured image
# To use, add an image named `featured.jpg/png` to your page's folder.
# Focal points: Smart, Center, TopLeft, Top, TopRight, Left, Right, BottomLeft, Bottom, BottomRight.
image:
  caption: ''
  focal_point: ''
  preview_only: false

# Projects (optional).
#   Associate this post with one or more of your projects.
#   Simply enter your project's folder or file name without extension.
#   E.g. `projects = ["internal-project"]` references `content/project/deep-learning/index.md`.
#   Otherwise, set `projects = []`.
projects: []
publishDate: '2021-04-06T13:49:41.458631Z'
publication_types:
- '2'
abstract: ''
publication: '*Nucleic Acids Research*'
url_pdf: https://www.scopus.com/inward/record.uri?eid=2-s2.0-84864443057&doi=10.1093%2fnar%2fgks460&partnerID=40&md5=84aea4f89aa0e57737765c1258c47fb0
doi: 10.1093/nar/gks460
---
