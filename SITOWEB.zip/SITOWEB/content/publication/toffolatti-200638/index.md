---
# Documentation: https://wowchemy.com/docs/managing-content/

title: Expression analysis of androgen-responsive genes in the prostate of veal calves
  treated with anabolic hormones
subtitle: ''
summary: ''
authors:
- L. Toffolatti
- L. Rosa Gastaldo
- T. Patarnello
- C. Romualdi
- R. Merlanti
- C. Montesissa
- L. Poppi
- M. Castagnaro
- L. Bargelloni
tags: []
categories: []
date: '2006-01-01'
lastmod: 2021-04-06T15:49:48+02:00
featured: false
draft: false

# Featured image
# To use, add an image named `featured.jpg/png` to your page's folder.
# Focal points: Smart, Center, TopLeft, Top, TopRight, Left, Right, BottomLeft, Bottom, BottomRight.
image:
  caption: ''
  focal_point: ''
  preview_only: false

# Projects (optional).
#   Associate this post with one or more of your projects.
#   Simply enter your project's folder or file name without extension.
#   E.g. `projects = ["internal-project"]` references `content/project/deep-learning/index.md`.
#   Otherwise, set `projects = []`.
projects: []
publishDate: '2021-04-06T13:49:48.419280Z'
publication_types:
- '2'
abstract: ''
publication: '*Domestic Animal Endocrinology*'
url_pdf: https://www.scopus.com/inward/record.uri?eid=2-s2.0-27844532048&doi=10.1016%2fj.domaniend.2005.05.008&partnerID=40&md5=1efb6519363ce9c0ba7fa495930c2e44
doi: 10.1016/j.domaniend.2005.05.008
---
