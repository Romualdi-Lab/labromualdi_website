---
# Documentation: https://wowchemy.com/docs/managing-content/

title: 'Altered glucose metabolism and proteolysis in pancreatic cancer cell conditioned
  myoblasts: Searching for a gene expression pattern with a microarray analysis of
  5000 skeletal muscle genes'
subtitle: ''
summary: ''
authors:
- D. Basso
- C. Millino
- E. Greco
- C. Romualdi
- P. Fogar
- A. Valerio
- M. Bellin
- C.-F. Zambon
- F. Navaglia
- N. Dussini
- A. Avogaro
- S. Pedrazzoli
- G. Lanfranchi
- M. Plebani
tags: []
categories: []
date: '2004-01-01'
lastmod: 2021-04-06T15:49:49+02:00
featured: false
draft: false

# Featured image
# To use, add an image named `featured.jpg/png` to your page's folder.
# Focal points: Smart, Center, TopLeft, Top, TopRight, Left, Right, BottomLeft, Bottom, BottomRight.
image:
  caption: ''
  focal_point: ''
  preview_only: false

# Projects (optional).
#   Associate this post with one or more of your projects.
#   Simply enter your project's folder or file name without extension.
#   E.g. `projects = ["internal-project"]` references `content/project/deep-learning/index.md`.
#   Otherwise, set `projects = []`.
projects: []
publishDate: '2021-04-06T13:49:49.545799Z'
publication_types:
- '2'
abstract: ''
publication: '*Gut*'
url_pdf: https://www.scopus.com/inward/record.uri?eid=2-s2.0-3242681430&doi=10.1136%2fgut.2003.024471&partnerID=40&md5=58611539d5e3694bca4a59e4fc75f8ba
doi: 10.1136/gut.2003.024471
---
