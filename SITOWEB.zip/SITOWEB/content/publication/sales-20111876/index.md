---
# Documentation: https://wowchemy.com/docs/managing-content/

title: Parmigene-a parallel R package for mutual information estimation and gene network
  reconstruction
subtitle: ''
summary: ''
authors:
- G. Sales
- C. Romualdi
tags: []
categories: []
date: '2011-01-01'
lastmod: 2021-04-06T15:49:42+02:00
featured: false
draft: false

# Featured image
# To use, add an image named `featured.jpg/png` to your page's folder.
# Focal points: Smart, Center, TopLeft, Top, TopRight, Left, Right, BottomLeft, Bottom, BottomRight.
image:
  caption: ''
  focal_point: ''
  preview_only: false

# Projects (optional).
#   Associate this post with one or more of your projects.
#   Simply enter your project's folder or file name without extension.
#   E.g. `projects = ["internal-project"]` references `content/project/deep-learning/index.md`.
#   Otherwise, set `projects = []`.
projects: []
publishDate: '2021-04-06T13:49:42.597765Z'
publication_types:
- '2'
abstract: ''
publication: '*Bioinformatics*'
url_pdf: https://www.scopus.com/inward/record.uri?eid=2-s2.0-79959425839&doi=10.1093%2fbioinformatics%2fbtr274&partnerID=40&md5=0d9a08b8b74aac8a1d9fbb6f1cab7374
doi: 10.1093/bioinformatics/btr274
---
