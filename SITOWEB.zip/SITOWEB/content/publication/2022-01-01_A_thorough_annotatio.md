+++
# Documentation: https://wowchemy.com/docs/managing-content/

title = "A thorough annotation of the krill transcriptome offers new insights for the study of physiological processes"
date = "2022-01-01"
authors = ["I. Urso", "A. Biscontin", "D. Corso", "C. Bertolucci", "C. Romualdi", "C. {De Pitta}", "B. Meyer", "G. Sales"]
publication_types = ["2"]
publication = "Scientific Reports, (12), 1, https://doi.org/10.1038/s41598-022-15320-5"
publication_short = "Scientific Reports, (12), 1, https://doi.org/10.1038/s41598-022-15320-5"
abstract = ""
abstract_short = ""
image_preview = ""
selected = false
projects = []
tags = []
url_pdf = ""
url_preprint = ""
url_code = ""
url_dataset = ""
url_project = ""
url_slides = ""
url_video = ""
url_poster = ""
url_source = ""
math = true
highlight = true
[header]
image = ""
caption = ""
+++
