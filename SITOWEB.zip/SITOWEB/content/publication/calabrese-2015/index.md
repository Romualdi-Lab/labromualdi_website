---
# Documentation: https://wowchemy.com/docs/managing-content/

title: Regional distribution and evolution of gray matter damage in different populations
  of multiple sclerosis patients
subtitle: ''
summary: ''
authors:
- M. Calabrese
- R. Reynolds
- R. Magliozzi
- M. Castellaro
- A. Morra
- A. Scalfari
- G. Farina
- C. Romualdi
- A. Gajofatto
- M. Pitteri
- M.D. Benedetti
- S. Monaco
tags: []
categories: []
date: '2015-01-01'
lastmod: 2021-04-06T15:49:37+02:00
featured: false
draft: false

# Featured image
# To use, add an image named `featured.jpg/png` to your page's folder.
# Focal points: Smart, Center, TopLeft, Top, TopRight, Left, Right, BottomLeft, Bottom, BottomRight.
image:
  caption: ''
  focal_point: ''
  preview_only: false

# Projects (optional).
#   Associate this post with one or more of your projects.
#   Simply enter your project's folder or file name without extension.
#   E.g. `projects = ["internal-project"]` references `content/project/deep-learning/index.md`.
#   Otherwise, set `projects = []`.
projects: []
publishDate: '2021-04-06T13:49:37.619535Z'
publication_types:
- '2'
abstract: ''
publication: '*PLoS ONE*'
url_pdf: https://www.scopus.com/inward/record.uri?eid=2-s2.0-84943180173&doi=10.1371%2fjournal.pone.0135428&partnerID=40&md5=6cd3c7dce403abca5e7eaf257d06ff0b
doi: 10.1371/journal.pone.0135428
---
