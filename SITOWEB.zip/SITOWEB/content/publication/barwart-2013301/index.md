---
# Documentation: https://wowchemy.com/docs/managing-content/

title: Headrace tunnel of the El Alto hydropower project in Panama [Druckstollen des
  wasserkraftprojekts El Alto in Panama]
subtitle: ''
summary: ''
authors:
- C. Barwart
- P. Romualdi
- A. Barioffi
tags: []
categories: []
date: '2013-01-01'
lastmod: 2021-04-06T15:49:39+02:00
featured: false
draft: false

# Featured image
# To use, add an image named `featured.jpg/png` to your page's folder.
# Focal points: Smart, Center, TopLeft, Top, TopRight, Left, Right, BottomLeft, Bottom, BottomRight.
image:
  caption: ''
  focal_point: ''
  preview_only: false

# Projects (optional).
#   Associate this post with one or more of your projects.
#   Simply enter your project's folder or file name without extension.
#   E.g. `projects = ["internal-project"]` references `content/project/deep-learning/index.md`.
#   Otherwise, set `projects = []`.
projects: []
publishDate: '2021-04-06T13:49:39.718970Z'
publication_types:
- '2'
abstract: ''
publication: '*Geomechanik und Tunnelbau*'
url_pdf: https://www.scopus.com/inward/record.uri?eid=2-s2.0-84880988271&doi=10.1002%2fgeot.201300019&partnerID=40&md5=118b0f2d94407ddfa917383786eefef7
doi: 10.1002/geot.201300019
---
