---
# Documentation: https://wowchemy.com/docs/managing-content/

title: Low degree of cortical pathology is associated with benign course of multiple
  sclerosis
subtitle: ''
summary: ''
authors:
- M. Calabrese
- A. Favaretto
- V. Poretto
- C. Romualdi
- F. Rinaldi
- I. Mattisi
- A. Morra
- P. Perini
- P. Gallo
tags: []
categories: []
date: '2013-01-01'
lastmod: 2021-04-06T15:49:41+02:00
featured: false
draft: false

# Featured image
# To use, add an image named `featured.jpg/png` to your page's folder.
# Focal points: Smart, Center, TopLeft, Top, TopRight, Left, Right, BottomLeft, Bottom, BottomRight.
image:
  caption: ''
  focal_point: ''
  preview_only: false

# Projects (optional).
#   Associate this post with one or more of your projects.
#   Simply enter your project's folder or file name without extension.
#   E.g. `projects = ["internal-project"]` references `content/project/deep-learning/index.md`.
#   Otherwise, set `projects = []`.
projects: []
publishDate: '2021-04-06T13:49:40.834117Z'
publication_types:
- '2'
abstract: ''
publication: '*Multiple Sclerosis Journal*'
url_pdf: https://www.scopus.com/inward/record.uri?eid=2-s2.0-84878353660&doi=10.1177%2f1352458512463767&partnerID=40&md5=315e9465fcca0e599d416dd4562ad0c7
doi: 10.1177/1352458512463767
---
