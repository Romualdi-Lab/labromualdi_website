---
# Documentation: https://wowchemy.com/docs/managing-content/

title: Gene expression profiling in skeletal muscle using a dedicated microarray
subtitle: ''
summary: ''
authors:
- S. Campanaro
- C. Romualdi
- C. De Pittà
- M. Fanin
- B. Celegato
- B. Pacchioni
- S. Trevisan
- P. Laveder
- S. Toppo
- S. Cagnin
- G. Valle
- C. Angelini
- G. Lanfranchi
tags: []
categories: []
date: '2002-01-01'
lastmod: 2021-04-06T15:49:51+02:00
featured: false
draft: false

# Featured image
# To use, add an image named `featured.jpg/png` to your page's folder.
# Focal points: Smart, Center, TopLeft, Top, TopRight, Left, Right, BottomLeft, Bottom, BottomRight.
image:
  caption: ''
  focal_point: ''
  preview_only: false

# Projects (optional).
#   Associate this post with one or more of your projects.
#   Simply enter your project's folder or file name without extension.
#   E.g. `projects = ["internal-project"]` references `content/project/deep-learning/index.md`.
#   Otherwise, set `projects = []`.
projects: []
publishDate: '2021-04-06T13:49:50.836974Z'
publication_types:
- '2'
abstract: ''
publication: '*Minerva Biotecnologica*'
url_pdf: https://www.scopus.com/inward/record.uri?eid=2-s2.0-0036978610&partnerID=40&md5=ac86decb6e616f150cb0f052bf0a6e60
---
