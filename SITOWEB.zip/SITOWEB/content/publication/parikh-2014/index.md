---
# Documentation: https://wowchemy.com/docs/managing-content/

title: MicroRNA-181a has a critical role in ovarian cancer progression through the
  regulation of the epithelial-mesenchymal transition
subtitle: ''
summary: ''
authors:
- A. Parikh
- C. Lee
- P. Joseph
- S. Marchini
- A. Baccarini
- V. Kolev
- C. Romualdi
- R. Fruscio
- H. Shah
- F. Wang
- G. Mullokandov
- D. Fishman
- M. D'Incalci
- J. Rahaman
- T. Kalir
- R.W. Redline
- B.D. Brown
- G. Narla
- A. Difeo
tags: []
categories: []
date: '2014-01-01'
lastmod: 2021-04-06T15:49:39+02:00
featured: false
draft: false

# Featured image
# To use, add an image named `featured.jpg/png` to your page's folder.
# Focal points: Smart, Center, TopLeft, Top, TopRight, Left, Right, BottomLeft, Bottom, BottomRight.
image:
  caption: ''
  focal_point: ''
  preview_only: false

# Projects (optional).
#   Associate this post with one or more of your projects.
#   Simply enter your project's folder or file name without extension.
#   E.g. `projects = ["internal-project"]` references `content/project/deep-learning/index.md`.
#   Otherwise, set `projects = []`.
projects: []
publishDate: '2021-04-06T13:49:39.036728Z'
publication_types:
- '2'
abstract: ''
publication: '*Nature Communications*'
url_pdf: https://www.scopus.com/inward/record.uri?eid=2-s2.0-84891883182&doi=10.1038%2fncomms3977&partnerID=40&md5=e126e0ede5cfb92e0c9829a5d82ec172
doi: 10.1038/ncomms3977
---
