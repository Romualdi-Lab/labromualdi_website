---
# Documentation: https://wowchemy.com/docs/managing-content/

title: Systems biology approach to the dissection of the complexity of regulatory
  networks in the S. scrofa cardiocirculatory system
subtitle: ''
summary: ''
authors:
- P. Martini
- G. Sales
- E. Calura
- M. Brugiolo
- G. Lanfranchi
- C. Romualdi
- S. Cagnin
tags: []
categories: []
date: '2013-01-01'
lastmod: 2021-04-06T15:49:39+02:00
featured: false
draft: false

# Featured image
# To use, add an image named `featured.jpg/png` to your page's folder.
# Focal points: Smart, Center, TopLeft, Top, TopRight, Left, Right, BottomLeft, Bottom, BottomRight.
image:
  caption: ''
  focal_point: ''
  preview_only: false

# Projects (optional).
#   Associate this post with one or more of your projects.
#   Simply enter your project's folder or file name without extension.
#   E.g. `projects = ["internal-project"]` references `content/project/deep-learning/index.md`.
#   Otherwise, set `projects = []`.
projects: []
publishDate: '2021-04-06T13:49:39.503898Z'
publication_types:
- '2'
abstract: ''
publication: '*International Journal of Molecular Sciences*'
url_pdf: https://www.scopus.com/inward/record.uri?eid=2-s2.0-84888195135&doi=10.3390%2fijms141123160&partnerID=40&md5=288d2ee431d05f75e75777a9624d5137
doi: 10.3390/ijms141123160
---
