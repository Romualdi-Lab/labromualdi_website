---
# Documentation: https://wowchemy.com/docs/managing-content/

title: Gene expression profiling identifies potential relevant genes in alveolar rhabdomyosarcoma
  pathogenesis and discriminates PAX3-FKHR positive and negative tumors
subtitle: ''
summary: ''
authors:
- C. De Pittà
- L. Tombolan
- G. Albiero
- F. Sartori
- C. Romualdi
- G. Jurman
- M. Carli
- C. Furlanello
- G. Lanfranchi
- A. Rosolen
tags: []
categories: []
date: '2006-01-01'
lastmod: 2021-04-06T15:49:48+02:00
featured: false
draft: false

# Featured image
# To use, add an image named `featured.jpg/png` to your page's folder.
# Focal points: Smart, Center, TopLeft, Top, TopRight, Left, Right, BottomLeft, Bottom, BottomRight.
image:
  caption: ''
  focal_point: ''
  preview_only: false

# Projects (optional).
#   Associate this post with one or more of your projects.
#   Simply enter your project's folder or file name without extension.
#   E.g. `projects = ["internal-project"]` references `content/project/deep-learning/index.md`.
#   Otherwise, set `projects = []`.
projects: []
publishDate: '2021-04-06T13:49:48.054808Z'
publication_types:
- '2'
abstract: ''
publication: '*International Journal of Cancer*'
url_pdf: https://www.scopus.com/inward/record.uri?eid=2-s2.0-33646382114&doi=10.1002%2fijc.21698&partnerID=40&md5=4d5ae92f5d7038e5e9266323abbf7eb0
doi: 10.1002/ijc.21698
---
