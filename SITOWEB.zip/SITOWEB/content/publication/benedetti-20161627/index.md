---
# Documentation: https://wowchemy.com/docs/managing-content/

title: Antimicrobial use and microbiological testing in district general hospital
  ICUs of the Veneto region of north-east Italy
subtitle: ''
summary: ''
authors:
- P. Benedetti
- A.M. Sefton
- M. Menegozzo
- C. Guerriero
- G. Bordignon
- G. Da Rin
- C. Romualdi
- G. Pellizzer
- D.M. Livermore
tags: []
categories: []
date: '2016-01-01'
lastmod: 2021-04-06T15:49:36+02:00
featured: false
draft: false

# Featured image
# To use, add an image named `featured.jpg/png` to your page's folder.
# Focal points: Smart, Center, TopLeft, Top, TopRight, Left, Right, BottomLeft, Bottom, BottomRight.
image:
  caption: ''
  focal_point: ''
  preview_only: false

# Projects (optional).
#   Associate this post with one or more of your projects.
#   Simply enter your project's folder or file name without extension.
#   E.g. `projects = ["internal-project"]` references `content/project/deep-learning/index.md`.
#   Otherwise, set `projects = []`.
projects: []
publishDate: '2021-04-06T13:49:36.271962Z'
publication_types:
- '2'
abstract: ''
publication: '*European Journal of Clinical Microbiology and Infectious Diseases*'
url_pdf: https://www.scopus.com/inward/record.uri?eid=2-s2.0-84974823841&doi=10.1007%2fs10096-016-2701-1&partnerID=40&md5=d22cd3bb33cb046746d4bdea315920e4
doi: 10.1007/s10096-016-2701-1
---
