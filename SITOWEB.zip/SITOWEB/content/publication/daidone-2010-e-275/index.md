---
# Documentation: https://wowchemy.com/docs/managing-content/

title: Microsatellite (GT)n is part of the von Willebrand factor (VWF) promoter region
  that influences the glucocorticoid-induced increase in VWF in Cushing's syndrome
subtitle: ''
summary: ''
authors:
- V. Daidone
- E. Pontara
- C. Romualdi
- M.G. Cattini
- C. Scaroni
- N. Albiger
- A. Pagnan
- A. Casonato
tags: []
categories: []
date: '2010-01-01'
lastmod: 2021-04-06T15:49:43+02:00
featured: false
draft: false

# Featured image
# To use, add an image named `featured.jpg/png` to your page's folder.
# Focal points: Smart, Center, TopLeft, Top, TopRight, Left, Right, BottomLeft, Bottom, BottomRight.
image:
  caption: ''
  focal_point: ''
  preview_only: false

# Projects (optional).
#   Associate this post with one or more of your projects.
#   Simply enter your project's folder or file name without extension.
#   E.g. `projects = ["internal-project"]` references `content/project/deep-learning/index.md`.
#   Otherwise, set `projects = []`.
projects: []
publishDate: '2021-04-06T13:49:43.464918Z'
publication_types:
- '2'
abstract: ''
publication: '*Thrombosis Research*'
url_pdf: https://www.scopus.com/inward/record.uri?eid=2-s2.0-77952543564&doi=10.1016%2fj.thromres.2010.01.031&partnerID=40&md5=34ff9646554b376f784fc3bbaa4c4036
doi: 10.1016/j.thromres.2010.01.031
---
