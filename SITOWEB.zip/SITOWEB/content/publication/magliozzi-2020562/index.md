---
# Documentation: https://wowchemy.com/docs/managing-content/

title: The CSF Profile Linked to Cortical Damage Predicts Multiple Sclerosis Activity
subtitle: ''
summary: ''
authors:
- R. Magliozzi
- A. Scalfari
- A.I. Pisani
- S. Ziccardi
- D. Marastoni
- F.B. Pizzini
- A. Bajrami
- A. Tamanti
- M. Guandalini
- S. Bonomi
- S. Rossi
- V. Mazziotti
- M. Castellaro
- S. Montemezzi
- S. Rasia
- R. Capra
- M. Pitteri
- C. Romualdi
- R. Reynolds
- M. Calabrese
tags: []
categories: []
date: '2020-01-01'
lastmod: 2021-04-06T15:49:31+02:00
featured: false
draft: false

# Featured image
# To use, add an image named `featured.jpg/png` to your page's folder.
# Focal points: Smart, Center, TopLeft, Top, TopRight, Left, Right, BottomLeft, Bottom, BottomRight.
image:
  caption: ''
  focal_point: ''
  preview_only: false

# Projects (optional).
#   Associate this post with one or more of your projects.
#   Simply enter your project's folder or file name without extension.
#   E.g. `projects = ["internal-project"]` references `content/project/deep-learning/index.md`.
#   Otherwise, set `projects = []`.
projects: []
publishDate: '2021-04-06T13:49:31.566926Z'
publication_types:
- '2'
abstract: ''
publication: '*Annals of Neurology*'
url_pdf: https://www.scopus.com/inward/record.uri?eid=2-s2.0-85087715214&doi=10.1002%2fana.25786&partnerID=40&md5=372589445287a340f1d1124e99266096
doi: 10.1002/ana.25786
---
