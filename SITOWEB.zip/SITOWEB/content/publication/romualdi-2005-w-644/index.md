---
# Documentation: https://wowchemy.com/docs/managing-content/

title: 'MIDAW: A web tool for statistical analysis of microarray data'
subtitle: ''
summary: ''
authors:
- C. Romualdi
- N. Vitulo
- M. Del Favero
- G. Lanfranchi
tags: []
categories: []
date: '2005-01-01'
lastmod: 2021-04-06T15:49:48+02:00
featured: false
draft: false

# Featured image
# To use, add an image named `featured.jpg/png` to your page's folder.
# Focal points: Smart, Center, TopLeft, Top, TopRight, Left, Right, BottomLeft, Bottom, BottomRight.
image:
  caption: ''
  focal_point: ''
  preview_only: false

# Projects (optional).
#   Associate this post with one or more of your projects.
#   Simply enter your project's folder or file name without extension.
#   E.g. `projects = ["internal-project"]` references `content/project/deep-learning/index.md`.
#   Otherwise, set `projects = []`.
projects: []
publishDate: '2021-04-06T13:49:48.708304Z'
publication_types:
- '2'
abstract: ''
publication: '*Nucleic Acids Research*'
url_pdf: https://www.scopus.com/inward/record.uri?eid=2-s2.0-23144442350&doi=10.1093%2fnar%2fgki497&partnerID=40&md5=91c09e43033c585d2da3d76fb65c19f7
doi: 10.1093/nar/gki497
---
