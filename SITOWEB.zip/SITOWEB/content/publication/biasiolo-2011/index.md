---
# Documentation: https://wowchemy.com/docs/managing-content/

title: Impact of host genes and strand selection on miRNA and miRNA* expression
subtitle: ''
summary: ''
authors:
- M. Biasiolo
- G. Sales
- M. Lionetti
- L. Agnelli
- K. Todoerti
- A. Bisognin
- A. Coppe
- C. Romualdi
- A. Neri
- S. Bortoluzzi
tags: []
categories: []
date: '2011-01-01'
lastmod: 2021-04-06T15:49:42+02:00
featured: false
draft: false

# Featured image
# To use, add an image named `featured.jpg/png` to your page's folder.
# Focal points: Smart, Center, TopLeft, Top, TopRight, Left, Right, BottomLeft, Bottom, BottomRight.
image:
  caption: ''
  focal_point: ''
  preview_only: false

# Projects (optional).
#   Associate this post with one or more of your projects.
#   Simply enter your project's folder or file name without extension.
#   E.g. `projects = ["internal-project"]` references `content/project/deep-learning/index.md`.
#   Otherwise, set `projects = []`.
projects: []
publishDate: '2021-04-06T13:49:42.379485Z'
publication_types:
- '2'
abstract: ''
publication: '*PLoS ONE*'
url_pdf: https://www.scopus.com/inward/record.uri?eid=2-s2.0-80052315517&doi=10.1371%2fjournal.pone.0023854&partnerID=40&md5=cb332e12c4a700669c5ae37f2c8e8f42
doi: 10.1371/journal.pone.0023854
---
