---
# Documentation: https://wowchemy.com/docs/managing-content/

title: 'Correlation between gene expression and clinical data through linear and nonlinear
  principal components analyses: Muscular dystrophies as case studies'
subtitle: ''
summary: ''
authors:
- C. Romualdi
- A. Giuliani
- C. Millino
- B. Celegato
- R. Benigni
- G. Lanfranchi
tags: []
categories: []
date: '2009-01-01'
lastmod: 2021-04-06T15:49:44+02:00
featured: false
draft: false

# Featured image
# To use, add an image named `featured.jpg/png` to your page's folder.
# Focal points: Smart, Center, TopLeft, Top, TopRight, Left, Right, BottomLeft, Bottom, BottomRight.
image:
  caption: ''
  focal_point: ''
  preview_only: false

# Projects (optional).
#   Associate this post with one or more of your projects.
#   Simply enter your project's folder or file name without extension.
#   E.g. `projects = ["internal-project"]` references `content/project/deep-learning/index.md`.
#   Otherwise, set `projects = []`.
projects: []
publishDate: '2021-04-06T13:49:44.704967Z'
publication_types:
- '2'
abstract: ''
publication: '*OMICS A Journal of Integrative Biology*'
url_pdf: https://www.scopus.com/inward/record.uri?eid=2-s2.0-67651152710&doi=10.1089%2fomi.2009.0003&partnerID=40&md5=931ccecb8b25ba1db6d79e71793e48ef
doi: 10.1089/omi.2009.0003
---
