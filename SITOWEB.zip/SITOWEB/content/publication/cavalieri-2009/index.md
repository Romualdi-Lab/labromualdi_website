---
# Documentation: https://wowchemy.com/docs/managing-content/

title: Filling gaps in PPAR-alpha signaling through comparative nutrigenomics analysis
subtitle: ''
summary: ''
authors:
- D. Cavalieri
- E. Calura
- C. Romualdi
- E. Marchi
- M. Radonjic
- B. Van Ommen
- M. Müller
tags: []
categories: []
date: '2009-01-01'
lastmod: 2021-04-06T15:49:44+02:00
featured: false
draft: false

# Featured image
# To use, add an image named `featured.jpg/png` to your page's folder.
# Focal points: Smart, Center, TopLeft, Top, TopRight, Left, Right, BottomLeft, Bottom, BottomRight.
image:
  caption: ''
  focal_point: ''
  preview_only: false

# Projects (optional).
#   Associate this post with one or more of your projects.
#   Simply enter your project's folder or file name without extension.
#   E.g. `projects = ["internal-project"]` references `content/project/deep-learning/index.md`.
#   Otherwise, set `projects = []`.
projects: []
publishDate: '2021-04-06T13:49:44.249780Z'
publication_types:
- '2'
abstract: ''
publication: '*BMC Genomics*'
url_pdf: https://www.scopus.com/inward/record.uri?eid=2-s2.0-74049088244&doi=10.1186%2f1471-2164-10-596&partnerID=40&md5=b62a55eafa8951c9e1ca36f59ce5ea88
doi: 10.1186/1471-2164-10-596
---
