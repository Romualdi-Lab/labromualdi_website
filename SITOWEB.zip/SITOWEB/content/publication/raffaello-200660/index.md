---
# Documentation: https://wowchemy.com/docs/managing-content/

title: 'Denervation in murine fast-twitch muscle: Short-term physiological changes
  and temporal expression profiling'
subtitle: ''
summary: ''
authors:
- A. Raffaello
- P. Laveder
- C. Romualdi
- C. Bean
- L. Toniolo
- E. Germinario
- A. Megighian
- D. Danieli-Betto
- C. Reggiani
- G. Lanfranchi
tags: []
categories: []
date: '2006-01-01'
lastmod: 2021-04-06T15:49:48+02:00
featured: false
draft: false

# Featured image
# To use, add an image named `featured.jpg/png` to your page's folder.
# Focal points: Smart, Center, TopLeft, Top, TopRight, Left, Right, BottomLeft, Bottom, BottomRight.
image:
  caption: ''
  focal_point: ''
  preview_only: false

# Projects (optional).
#   Associate this post with one or more of your projects.
#   Simply enter your project's folder or file name without extension.
#   E.g. `projects = ["internal-project"]` references `content/project/deep-learning/index.md`.
#   Otherwise, set `projects = []`.
projects: []
publishDate: '2021-04-06T13:49:48.252433Z'
publication_types:
- '2'
abstract: ''
publication: '*Physiological Genomics*'
url_pdf: https://www.scopus.com/inward/record.uri?eid=2-s2.0-33645774156&doi=10.1152%2fphysiolgenomics.00051.2005&partnerID=40&md5=0799947dfb32628e9913faf9d2e69bff
doi: 10.1152/physiolgenomics.00051.2005
---
