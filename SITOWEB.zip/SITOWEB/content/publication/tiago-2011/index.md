---
# Documentation: https://wowchemy.com/docs/managing-content/

title: 'Global analysis of gene expression in mineralizing fish vertebra-derived cell
  lines: New insights into anti-mineralogenic effect of vanadate'
subtitle: ''
summary: ''
authors:
- D.M. Tiago
- V. Laizé
- L. Bargelloni
- S. Ferraresso
- C. Romualdi
- M.L. Cancela
tags: []
categories: []
date: '2011-01-01'
lastmod: 2021-04-06T15:49:42+02:00
featured: false
draft: false

# Featured image
# To use, add an image named `featured.jpg/png` to your page's folder.
# Focal points: Smart, Center, TopLeft, Top, TopRight, Left, Right, BottomLeft, Bottom, BottomRight.
image:
  caption: ''
  focal_point: ''
  preview_only: false

# Projects (optional).
#   Associate this post with one or more of your projects.
#   Simply enter your project's folder or file name without extension.
#   E.g. `projects = ["internal-project"]` references `content/project/deep-learning/index.md`.
#   Otherwise, set `projects = []`.
projects: []
publishDate: '2021-04-06T13:49:42.740771Z'
publication_types:
- '2'
abstract: ''
publication: '*BMC Genomics*'
url_pdf: https://www.scopus.com/inward/record.uri?eid=2-s2.0-79958271271&doi=10.1186%2f1471-2164-12-310&partnerID=40&md5=a97e91509318a9c22108a2794987f52a
doi: 10.1186/1471-2164-12-310
---
