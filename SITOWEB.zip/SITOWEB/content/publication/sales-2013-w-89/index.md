---
# Documentation: https://wowchemy.com/docs/managing-content/

title: 'Graphite Web: Web tool for gene set analysis exploiting pathway topology.'
subtitle: ''
summary: ''
authors:
- G. Sales
- E. Calura
- P. Martini
- C. Romualdi
tags: []
categories: []
date: '2013-01-01'
lastmod: 2021-04-06T15:49:40+02:00
featured: false
draft: false

# Featured image
# To use, add an image named `featured.jpg/png` to your page's folder.
# Focal points: Smart, Center, TopLeft, Top, TopRight, Left, Right, BottomLeft, Bottom, BottomRight.
image:
  caption: ''
  focal_point: ''
  preview_only: false

# Projects (optional).
#   Associate this post with one or more of your projects.
#   Simply enter your project's folder or file name without extension.
#   E.g. `projects = ["internal-project"]` references `content/project/deep-learning/index.md`.
#   Otherwise, set `projects = []`.
projects: []
publishDate: '2021-04-06T13:49:40.725524Z'
publication_types:
- '2'
abstract: ''
publication: '*Nucleic acids research*'
url_pdf: https://www.scopus.com/inward/record.uri?eid=2-s2.0-84883595410&doi=10.1093%2fnar%2fgkt386&partnerID=40&md5=780e1b17f44c0e805ccfdc698d2f4d86
doi: 10.1093/nar/gkt386
---
