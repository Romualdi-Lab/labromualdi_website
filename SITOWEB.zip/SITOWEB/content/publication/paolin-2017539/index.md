---
# Documentation: https://wowchemy.com/docs/managing-content/

title: Analysis of potential factors affecting allografts contamination at retrieval
subtitle: ''
summary: ''
authors:
- A. Paolin
- C. Romualdi
- L. Romagnoli
- D. Trojan
tags: []
categories: []
date: '2017-01-01'
lastmod: 2021-04-06T15:49:34+02:00
featured: false
draft: false

# Featured image
# To use, add an image named `featured.jpg/png` to your page's folder.
# Focal points: Smart, Center, TopLeft, Top, TopRight, Left, Right, BottomLeft, Bottom, BottomRight.
image:
  caption: ''
  focal_point: ''
  preview_only: false

# Projects (optional).
#   Associate this post with one or more of your projects.
#   Simply enter your project's folder or file name without extension.
#   E.g. `projects = ["internal-project"]` references `content/project/deep-learning/index.md`.
#   Otherwise, set `projects = []`.
projects: []
publishDate: '2021-04-06T13:49:34.815596Z'
publication_types:
- '2'
abstract: ''
publication: '*Cell and Tissue Banking*'
url_pdf: https://www.scopus.com/inward/record.uri?eid=2-s2.0-85031498494&doi=10.1007%2fs10561-017-9667-9&partnerID=40&md5=a4ff9c33b240baf15c4638aab15b2426
doi: 10.1007/s10561-017-9667-9
---
