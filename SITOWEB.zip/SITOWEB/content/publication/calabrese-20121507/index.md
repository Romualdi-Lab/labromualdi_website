---
# Documentation: https://wowchemy.com/docs/managing-content/

title: 'Gray matter pathology in MS: A 3-year longitudinal study in a pediatric population'
subtitle: ''
summary: ''
authors:
- M. Calabrese
- D. Seppi
- C. Romualdi
- F. Rinaldi
- S. Alessio
- P. Perini
- P. Gallo
tags: []
categories: []
date: '2012-01-01'
lastmod: 2021-04-06T15:49:41+02:00
featured: false
draft: false

# Featured image
# To use, add an image named `featured.jpg/png` to your page's folder.
# Focal points: Smart, Center, TopLeft, Top, TopRight, Left, Right, BottomLeft, Bottom, BottomRight.
image:
  caption: ''
  focal_point: ''
  preview_only: false

# Projects (optional).
#   Associate this post with one or more of your projects.
#   Simply enter your project's folder or file name without extension.
#   E.g. `projects = ["internal-project"]` references `content/project/deep-learning/index.md`.
#   Otherwise, set `projects = []`.
projects: []
publishDate: '2021-04-06T13:49:41.348826Z'
publication_types:
- '2'
abstract: ''
publication: '*American Journal of Neuroradiology*'
url_pdf: https://www.scopus.com/inward/record.uri?eid=2-s2.0-84866361899&doi=10.3174%2fajnr.A3011&partnerID=40&md5=4289eda7e28c12aaea7d9c6c77a81bea
doi: 10.3174/ajnr.A3011
---
