---
# Documentation: https://wowchemy.com/docs/managing-content/

title: Magnetic resonance evidence of cerebellar cortical pathology in multiple sclerosis
subtitle: ''
summary: ''
authors:
- M. Calabrese
- I. Mattisi
- F. Rinaldi
- A. Favaretto
- M. Atzori
- V. Bernardi
- L. Barachino
- C. Romualdi
- L. Rinaldi
- P. Perini
- P. Gallo
tags: []
categories: []
date: '2010-01-01'
lastmod: 2021-04-06T15:49:43+02:00
featured: false
draft: false

# Featured image
# To use, add an image named `featured.jpg/png` to your page's folder.
# Focal points: Smart, Center, TopLeft, Top, TopRight, Left, Right, BottomLeft, Bottom, BottomRight.
image:
  caption: ''
  focal_point: ''
  preview_only: false

# Projects (optional).
#   Associate this post with one or more of your projects.
#   Simply enter your project's folder or file name without extension.
#   E.g. `projects = ["internal-project"]` references `content/project/deep-learning/index.md`.
#   Otherwise, set `projects = []`.
projects: []
publishDate: '2021-04-06T13:49:43.792559Z'
publication_types:
- '2'
abstract: ''
publication: '*Journal of Neurology, Neurosurgery and Psychiatry*'
url_pdf: https://www.scopus.com/inward/record.uri?eid=2-s2.0-77950615873&doi=10.1136%2fjnnp.2009.177733&partnerID=40&md5=2d2ec673d2f56aff6b8a1648469ffac0
doi: 10.1136/jnnp.2009.177733
---
