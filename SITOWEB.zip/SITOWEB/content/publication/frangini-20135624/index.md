---
# Documentation: https://wowchemy.com/docs/managing-content/

title: Synthesis of mitochondrial DNA precursors during myogenesis, an analysis in
  purified C2C12 myotubes
subtitle: ''
summary: ''
authors:
- M. Frangini
- E. Franzolin
- F. Chemello
- P. Laveder
- C. Romualdi
- V. Bianchi
- C. Rampazzo
tags: []
categories: []
date: '2013-01-01'
lastmod: 2021-04-06T15:49:40+02:00
featured: false
draft: false

# Featured image
# To use, add an image named `featured.jpg/png` to your page's folder.
# Focal points: Smart, Center, TopLeft, Top, TopRight, Left, Right, BottomLeft, Bottom, BottomRight.
image:
  caption: ''
  focal_point: ''
  preview_only: false

# Projects (optional).
#   Associate this post with one or more of your projects.
#   Simply enter your project's folder or file name without extension.
#   E.g. `projects = ["internal-project"]` references `content/project/deep-learning/index.md`.
#   Otherwise, set `projects = []`.
projects: []
publishDate: '2021-04-06T13:49:40.511598Z'
publication_types:
- '2'
abstract: ''
publication: '*Journal of Biological Chemistry*'
url_pdf: https://www.scopus.com/inward/record.uri?eid=2-s2.0-84874306753&doi=10.1074%2fjbc.M112.441147&partnerID=40&md5=69e03445a6c445da620961318a3616d5
doi: 10.1074/jbc.M112.441147
---
