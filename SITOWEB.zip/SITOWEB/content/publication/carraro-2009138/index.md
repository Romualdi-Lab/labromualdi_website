---
# Documentation: https://wowchemy.com/docs/managing-content/

title: Expression profiling of skeletal muscle in young bulls treated with steroidal
  growth promoters
subtitle: ''
summary: ''
authors:
- L. Carraro
- S. Ferraresso
- B. Cardazzo
- C. Romualdi
- C. Montesissa
- F. Gottardo
- T. Patarnello
- M. Castagnaro
- L. Bargelloni
tags: []
categories: []
date: '2009-01-01'
lastmod: 2021-04-06T15:49:44+02:00
featured: false
draft: false

# Featured image
# To use, add an image named `featured.jpg/png` to your page's folder.
# Focal points: Smart, Center, TopLeft, Top, TopRight, Left, Right, BottomLeft, Bottom, BottomRight.
image:
  caption: ''
  focal_point: ''
  preview_only: false

# Projects (optional).
#   Associate this post with one or more of your projects.
#   Simply enter your project's folder or file name without extension.
#   E.g. `projects = ["internal-project"]` references `content/project/deep-learning/index.md`.
#   Otherwise, set `projects = []`.
projects: []
publishDate: '2021-04-06T13:49:44.487944Z'
publication_types:
- '2'
abstract: ''
publication: '*Physiological Genomics*'
url_pdf: https://www.scopus.com/inward/record.uri?eid=2-s2.0-67650269852&doi=10.1152%2fphysiolgenomics.00014.2009&partnerID=40&md5=e7b4c0fcb61fdb91947dbba3b0595c36
doi: 10.1152/physiolgenomics.00014.2009
---
