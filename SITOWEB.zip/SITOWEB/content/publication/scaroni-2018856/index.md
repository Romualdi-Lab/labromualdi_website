---
# Documentation: https://wowchemy.com/docs/managing-content/

title: Paradoxical GH Increase during OGTT Is Associated with First-Generation Somatostatin
  Analog Responsiveness in Acromegaly
subtitle: ''
summary: ''
authors:
- C. Scaroni
- N. Albiger
- A. Daniele
- F. Dassie
- C. Romualdi
- G. Vazza
- D. Regazzo
- F. Ferraù
- V. Barresi
- V. Maffeis
- M.P. Gardiman
- S. Cannavò
- P. Maffei
- F. Ceccato
- M. Losa
- G. Occhi
tags: []
categories: []
date: '2018-01-01'
lastmod: 2021-04-06T15:49:34+02:00
featured: false
draft: false

# Featured image
# To use, add an image named `featured.jpg/png` to your page's folder.
# Focal points: Smart, Center, TopLeft, Top, TopRight, Left, Right, BottomLeft, Bottom, BottomRight.
image:
  caption: ''
  focal_point: ''
  preview_only: false

# Projects (optional).
#   Associate this post with one or more of your projects.
#   Simply enter your project's folder or file name without extension.
#   E.g. `projects = ["internal-project"]` references `content/project/deep-learning/index.md`.
#   Otherwise, set `projects = []`.
projects: []
publishDate: '2021-04-06T13:49:34.160569Z'
publication_types:
- '2'
abstract: ''
publication: '*Journal of Clinical Endocrinology and Metabolism*'
url_pdf: https://www.scopus.com/inward/record.uri?eid=2-s2.0-85060980738&doi=10.1210%2fjc.2018-01360&partnerID=40&md5=8c60f92631e5bc1e864082a59479f617
doi: 10.1210/jc.2018-01360
---
