---
# Documentation: https://wowchemy.com/docs/managing-content/

title: Microbiota of the therapeutic Euganean thermal muds with a focus on the main
  cyanobacteria species
subtitle: ''
summary: ''
authors:
- B. Gris
- L. Treu
- R.M. Zampieri
- F. Caldara
- C. Romualdi
- S. Campanaro
- N. La Rocca
tags: []
categories: []
date: '2020-01-01'
lastmod: 2021-04-06T15:49:31+02:00
featured: false
draft: false

# Featured image
# To use, add an image named `featured.jpg/png` to your page's folder.
# Focal points: Smart, Center, TopLeft, Top, TopRight, Left, Right, BottomLeft, Bottom, BottomRight.
image:
  caption: ''
  focal_point: ''
  preview_only: false

# Projects (optional).
#   Associate this post with one or more of your projects.
#   Simply enter your project's folder or file name without extension.
#   E.g. `projects = ["internal-project"]` references `content/project/deep-learning/index.md`.
#   Otherwise, set `projects = []`.
projects: []
publishDate: '2021-04-06T13:49:31.050662Z'
publication_types:
- '2'
abstract: ''
publication: '*Microorganisms*'
url_pdf: https://www.scopus.com/inward/record.uri?eid=2-s2.0-85092697366&doi=10.3390%2fmicroorganisms8101590&partnerID=40&md5=510dac6d22b4191fc0f8a9e0fb44281e
doi: 10.3390/microorganisms8101590
---
