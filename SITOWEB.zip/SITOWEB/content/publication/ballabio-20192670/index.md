---
# Documentation: https://wowchemy.com/docs/managing-content/

title: Multisite analysis of high-grade serous epithelial ovarian cancers identifies
  genomic regions of focal and recurrent copy number alteration in 3q26.2 and 8q24.3
subtitle: ''
summary: ''
authors:
- S. Ballabio
- I. Craparotta
- L. Paracchini
- L. Mannarino
- S. Corso
- M.G. Pezzotta
- M. Vescio
- R. Fruscio
- C. Romualdi
- E. Dainese
- L. Ceppi
- E. Calura
- S. Pileggi
- G. Siravegna
- L. Pattini
- P. Martini
- M. delle Marchette
- C. Mangioni
- A. Ardizzoia
- A. Pellegrino
- F. Landoni
- M. D'Incalci
- L. Beltrame
- S. Marchini
tags: []
categories: []
date: '2019-01-01'
lastmod: 2021-04-06T15:49:32+02:00
featured: false
draft: false

# Featured image
# To use, add an image named `featured.jpg/png` to your page's folder.
# Focal points: Smart, Center, TopLeft, Top, TopRight, Left, Right, BottomLeft, Bottom, BottomRight.
image:
  caption: ''
  focal_point: ''
  preview_only: false

# Projects (optional).
#   Associate this post with one or more of your projects.
#   Simply enter your project's folder or file name without extension.
#   E.g. `projects = ["internal-project"]` references `content/project/deep-learning/index.md`.
#   Otherwise, set `projects = []`.
projects: []
publishDate: '2021-04-06T13:49:32.612215Z'
publication_types:
- '2'
abstract: ''
publication: '*International Journal of Cancer*'
url_pdf: https://www.scopus.com/inward/record.uri?eid=2-s2.0-85065120453&doi=10.1002%2fijc.32288&partnerID=40&md5=f8d0f159fb2f9e0b6182e295fbc7eaf5
doi: 10.1002/ijc.32288
---
