---
# Documentation: https://wowchemy.com/docs/managing-content/

title: 'Cortical lesions in primary progressive multiple sclerosis: A 2-year longitudinal
  MR study'
subtitle: ''
summary: ''
authors:
- M. Calabrese
- M.A. Rocca
- M. Atzori
- I. Mattisi
- V. Bernardi
- A. Favaretto
- L. Barachino
- C. Romualdi
- L. Rinaldi
- P. Perini
- P. Gallo
- M. Filippi
tags: []
categories: []
date: '2009-01-01'
lastmod: 2021-04-06T15:49:44+02:00
featured: false
draft: false

# Featured image
# To use, add an image named `featured.jpg/png` to your page's folder.
# Focal points: Smart, Center, TopLeft, Top, TopRight, Left, Right, BottomLeft, Bottom, BottomRight.
image:
  caption: ''
  focal_point: ''
  preview_only: false

# Projects (optional).
#   Associate this post with one or more of your projects.
#   Simply enter your project's folder or file name without extension.
#   E.g. `projects = ["internal-project"]` references `content/project/deep-learning/index.md`.
#   Otherwise, set `projects = []`.
projects: []
publishDate: '2021-04-06T13:49:44.812633Z'
publication_types:
- '2'
abstract: ''
publication: '*Neurology*'
url_pdf: https://www.scopus.com/inward/record.uri?eid=2-s2.0-65349092772&doi=10.1212%2fWNL.0b013e3181a0fee5&partnerID=40&md5=97715869fd2bf3c3f192a6aaa0f76547
doi: 10.1212/WNL.0b013e3181a0fee5
---
