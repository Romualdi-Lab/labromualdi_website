---
# Documentation: https://wowchemy.com/docs/managing-content/

title: 'Smokers and passive smokers gene expression profiles: Correlation with the
  DNA oxidation damage'
subtitle: ''
summary: ''
authors:
- M. Lodovici
- C. Luceri
- C. De Filippo
- C. Romualdi
- F. Bambi
- P. Dolara
tags: []
categories: []
date: '2007-01-01'
lastmod: 2021-04-06T15:49:46+02:00
featured: false
draft: false

# Featured image
# To use, add an image named `featured.jpg/png` to your page's folder.
# Focal points: Smart, Center, TopLeft, Top, TopRight, Left, Right, BottomLeft, Bottom, BottomRight.
image:
  caption: ''
  focal_point: ''
  preview_only: false

# Projects (optional).
#   Associate this post with one or more of your projects.
#   Simply enter your project's folder or file name without extension.
#   E.g. `projects = ["internal-project"]` references `content/project/deep-learning/index.md`.
#   Otherwise, set `projects = []`.
projects: []
publishDate: '2021-04-06T13:49:46.599890Z'
publication_types:
- '2'
abstract: ''
publication: '*Free Radical Biology and Medicine*'
url_pdf: https://www.scopus.com/inward/record.uri?eid=2-s2.0-34250890852&doi=10.1016%2fj.freeradbiomed.2007.04.018&partnerID=40&md5=7fa726aac48ff2824ce79785a41df391
doi: 10.1016/j.freeradbiomed.2007.04.018
---
