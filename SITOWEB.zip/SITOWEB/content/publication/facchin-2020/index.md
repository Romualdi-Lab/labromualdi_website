---
# Documentation: https://wowchemy.com/docs/managing-content/

title: Microbiota changes induced by microencapsulated sodium butyrate in patients
  with inflammatory bowel disease
subtitle: ''
summary: ''
authors:
- S. Facchin
- N. Vitulo
- M. Calgaro
- A. Buda
- C. Romualdi
- D. Pohl
- B. Perini
- G. Lorenzon
- C. Marinelli
- R. D’Incà
- G.C. Sturniolo
- E.V. Savarino
tags: []
categories: []
date: '2020-01-01'
lastmod: 2021-04-06T15:49:31+02:00
featured: false
draft: false

# Featured image
# To use, add an image named `featured.jpg/png` to your page's folder.
# Focal points: Smart, Center, TopLeft, Top, TopRight, Left, Right, BottomLeft, Bottom, BottomRight.
image:
  caption: ''
  focal_point: ''
  preview_only: false

# Projects (optional).
#   Associate this post with one or more of your projects.
#   Simply enter your project's folder or file name without extension.
#   E.g. `projects = ["internal-project"]` references `content/project/deep-learning/index.md`.
#   Otherwise, set `projects = []`.
projects: []
publishDate: '2021-04-06T13:49:31.221341Z'
publication_types:
- '2'
abstract: ''
publication: '*Neurogastroenterology and Motility*'
url_pdf: https://www.scopus.com/inward/record.uri?eid=2-s2.0-85085629313&doi=10.1111%2fnmo.13914&partnerID=40&md5=47ec555ee8eb595891b153c974c78aa9
doi: 10.1111/nmo.13914
---
