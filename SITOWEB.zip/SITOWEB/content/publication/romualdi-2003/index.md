---
# Documentation: https://wowchemy.com/docs/managing-content/

title: Improved detection of differentially expressed genes in microarray experiments
  through multiple scanning and image integration.
subtitle: ''
summary: ''
authors:
- C. Romualdi
- S. Trevisan
- B. Celegato
- G. Costa
- G. Lanfranchi
tags: []
categories: []
date: '2003-01-01'
lastmod: 2021-04-06T15:49:50+02:00
featured: false
draft: false

# Featured image
# To use, add an image named `featured.jpg/png` to your page's folder.
# Focal points: Smart, Center, TopLeft, Top, TopRight, Left, Right, BottomLeft, Bottom, BottomRight.
image:
  caption: ''
  focal_point: ''
  preview_only: false

# Projects (optional).
#   Associate this post with one or more of your projects.
#   Simply enter your project's folder or file name without extension.
#   E.g. `projects = ["internal-project"]` references `content/project/deep-learning/index.md`.
#   Otherwise, set `projects = []`.
projects: []
publishDate: '2021-04-06T13:49:50.361580Z'
publication_types:
- '2'
abstract: ''
publication: '*Nucleic acids research*'
url_pdf: https://www.scopus.com/inward/record.uri?eid=2-s2.0-84883838178&doi=10.1093%2fnar%2fgng149&partnerID=40&md5=8ef4eeb7541d2e60b9026245f92c37a2
doi: 10.1093/nar/gng149
---
