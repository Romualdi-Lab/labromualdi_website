---
# Documentation: https://wowchemy.com/docs/managing-content/

title: Simulating gene silencing through intervention analysis
subtitle: ''
summary: ''
authors:
- V. Djordjilović
- M. Chiogna
- C. Romualdi
tags: []
categories: []
date: '2020-01-01'
lastmod: 2021-04-06T15:49:31+02:00
featured: false
draft: false

# Featured image
# To use, add an image named `featured.jpg/png` to your page's folder.
# Focal points: Smart, Center, TopLeft, Top, TopRight, Left, Right, BottomLeft, Bottom, BottomRight.
image:
  caption: ''
  focal_point: ''
  preview_only: false

# Projects (optional).
#   Associate this post with one or more of your projects.
#   Simply enter your project's folder or file name without extension.
#   E.g. `projects = ["internal-project"]` references `content/project/deep-learning/index.md`.
#   Otherwise, set `projects = []`.
projects: []
publishDate: '2021-04-06T13:49:31.783033Z'
publication_types:
- '2'
abstract: ''
publication: '*Journal of the Royal Statistical Society. Series C: Applied Statistics*'
url_pdf: https://www.scopus.com/inward/record.uri?eid=2-s2.0-85084137123&doi=10.1111%2frssc.12412&partnerID=40&md5=fc67baee7fc0da219bfdb16747d9bc8c
doi: 10.1111/rssc.12412
---
