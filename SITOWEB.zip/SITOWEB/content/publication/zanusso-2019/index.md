---
# Documentation: https://wowchemy.com/docs/managing-content/

title: Rs4143815-PDL1, a new potential immunogenetic biomarker of biochemical recurrence
  in locally advanced prostate cancer after radiotherapy
subtitle: ''
summary: ''
authors:
- C. Zanusso
- E. Dreussi
- R. Bortolus
- C. Romualdi
- S. Gagno
- E. De Mattia
- L. Romanato
- F. Sartor
- L. Quartuccio
- E. Cecchin
- G. Toffoli
tags: []
categories: []
date: '2019-01-01'
lastmod: 2021-04-06T15:49:33+02:00
featured: false
draft: false

# Featured image
# To use, add an image named `featured.jpg/png` to your page's folder.
# Focal points: Smart, Center, TopLeft, Top, TopRight, Left, Right, BottomLeft, Bottom, BottomRight.
image:
  caption: ''
  focal_point: ''
  preview_only: false

# Projects (optional).
#   Associate this post with one or more of your projects.
#   Simply enter your project's folder or file name without extension.
#   E.g. `projects = ["internal-project"]` references `content/project/deep-learning/index.md`.
#   Otherwise, set `projects = []`.
projects: []
publishDate: '2021-04-06T13:49:33.140352Z'
publication_types:
- '2'
abstract: ''
publication: '*International Journal of Molecular Sciences*'
url_pdf: https://www.scopus.com/inward/record.uri?eid=2-s2.0-85065499184&doi=10.3390%2fijms20092082&partnerID=40&md5=fad029d561a1adccf87741531efd3008
doi: 10.3390/ijms20092082
---
