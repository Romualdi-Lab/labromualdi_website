---
# Documentation: https://wowchemy.com/docs/managing-content/

title: 'Statistical Test of Expression Pattern (STEPath): A new strategy to integrate
  gene expression data with genomic information in individual and meta-analysis studies'
subtitle: ''
summary: ''
authors:
- P. Martini
- D. Risso
- G. Sales
- C. Romualdi
- G. Lanfranchi
- S. Cagnin
tags: []
categories: []
date: '2011-01-01'
lastmod: 2021-04-06T15:49:43+02:00
featured: false
draft: false

# Featured image
# To use, add an image named `featured.jpg/png` to your page's folder.
# Focal points: Smart, Center, TopLeft, Top, TopRight, Left, Right, BottomLeft, Bottom, BottomRight.
image:
  caption: ''
  focal_point: ''
  preview_only: false

# Projects (optional).
#   Associate this post with one or more of your projects.
#   Simply enter your project's folder or file name without extension.
#   E.g. `projects = ["internal-project"]` references `content/project/deep-learning/index.md`.
#   Otherwise, set `projects = []`.
projects: []
publishDate: '2021-04-06T13:49:42.849126Z'
publication_types:
- '2'
abstract: ''
publication: '*BMC Bioinformatics*'
url_pdf: https://www.scopus.com/inward/record.uri?eid=2-s2.0-79953776855&doi=10.1186%2f1471-2105-12-92&partnerID=40&md5=5708034f1608fad3c64056b5a23f4830
doi: 10.1186/1471-2105-12-92
---
