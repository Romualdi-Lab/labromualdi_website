+++
title = "BrewerIX enables allelic expression analysis of imprinted and X-linked genes from bulk and single-cell transcriptomes"
date = "2022-01-01"
authors = ["P. Martini", "G. Sales", "L. Diamante", "V. Perrera", "C. Colantuono", "S. Riccardo", "D. Cacchiarelli", "C. Romualdi", "G. Martello"]
publication_types = ["2"]
publication = "Communications Biology, (5), 1, https://doi.org/10.1038/s42003-022-03087-4"
publication_short = "Communications Biology, (5), 1, https://doi.org/10.1038/s42003-022-03087-4"
abstract = ""
abstract_short = ""
image_preview = ""
selected = false
projects = []
tags = []
url_pdf = ""
url_preprint = ""
url_code = ""
url_dataset = ""
url_project = ""
url_slides = ""
url_video = ""
url_poster = ""
url_source = ""
math = true
highlight = true
[header]
image = ""
caption = ""
+++
