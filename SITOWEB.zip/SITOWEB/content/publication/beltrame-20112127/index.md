---
# Documentation: https://wowchemy.com/docs/managing-content/

title: 'The biological Connection Markup Language: A SBGN-compliant format for visualization,
  filtering and analysis of biological pathways'
subtitle: ''
summary: ''
authors:
- L. Beltrame
- E. Calura
- R.R. Popovici
- L. Rizzetto
- D.R. Guedez
- M. Donato
- C. Romualdi
- S. Draghici
- D. Cavalieri
tags: []
categories: []
date: '2011-01-01'
lastmod: 2021-04-06T15:49:42+02:00
featured: false
draft: false

# Featured image
# To use, add an image named `featured.jpg/png` to your page's folder.
# Focal points: Smart, Center, TopLeft, Top, TopRight, Left, Right, BottomLeft, Bottom, BottomRight.
image:
  caption: ''
  focal_point: ''
  preview_only: false

# Projects (optional).
#   Associate this post with one or more of your projects.
#   Simply enter your project's folder or file name without extension.
#   E.g. `projects = ["internal-project"]` references `content/project/deep-learning/index.md`.
#   Otherwise, set `projects = []`.
projects: []
publishDate: '2021-04-06T13:49:42.487760Z'
publication_types:
- '2'
abstract: ''
publication: '*Bioinformatics*'
url_pdf: https://www.scopus.com/inward/record.uri?eid=2-s2.0-79960414803&doi=10.1093%2fbioinformatics%2fbtr339&partnerID=40&md5=781215990777d285c1a56380f1c948d3
doi: 10.1093/bioinformatics/btr339
---
