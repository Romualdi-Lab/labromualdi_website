---
# Documentation: https://wowchemy.com/docs/managing-content/

title: 'COLOMBOS v3.0: Leveraging gene expression compendia for cross-species analyses'
subtitle: ''
summary: ''
authors:
- M. Moretto
- P. Sonego
- N. Dierckxsens
- M. Brilli
- L. Bianco
- D. Ledezma-Tejeida
- S. Gama-Castro
- M. Galardini
- C. Romualdi
- K. Laukens
- J. Collado-Vides
- P. Meysman
- K. Engelen
tags: []
categories: []
date: '2016-01-01'
lastmod: 2021-04-06T15:49:37+02:00
featured: false
draft: false

# Featured image
# To use, add an image named `featured.jpg/png` to your page's folder.
# Focal points: Smart, Center, TopLeft, Top, TopRight, Left, Right, BottomLeft, Bottom, BottomRight.
image:
  caption: ''
  focal_point: ''
  preview_only: false

# Projects (optional).
#   Associate this post with one or more of your projects.
#   Simply enter your project's folder or file name without extension.
#   E.g. `projects = ["internal-project"]` references `content/project/deep-learning/index.md`.
#   Otherwise, set `projects = []`.
projects: []
publishDate: '2021-04-06T13:49:36.887897Z'
publication_types:
- '2'
abstract: ''
publication: '*Nucleic Acids Research*'
url_pdf: https://www.scopus.com/inward/record.uri?eid=2-s2.0-84976905759&doi=10.1093%2fnar%2fgkv1251&partnerID=40&md5=8e02d12bcfc8c7f71893ef34f4749e84
doi: 10.1093/nar/gkv1251
---
