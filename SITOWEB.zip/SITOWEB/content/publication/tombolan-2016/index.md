---
# Documentation: https://wowchemy.com/docs/managing-content/

title: Global DNA methylation profiling uncovers distinct methylation patterns of
  protocadherin alpha4 in metastatic and non-metastatic rhabdomyosarcoma
subtitle: ''
summary: ''
authors:
- L. Tombolan
- E. Poli
- P. Martini
- A. Zin
- C. Millino
- B. Pacchioni
- B. Celegato
- G. Bisogno
- C. Romualdi
- A. Rosolen
- G. Lanfranchi
tags: []
categories: []
date: '2016-01-01'
lastmod: 2021-04-06T15:49:36+02:00
featured: false
draft: false

# Featured image
# To use, add an image named `featured.jpg/png` to your page's folder.
# Focal points: Smart, Center, TopLeft, Top, TopRight, Left, Right, BottomLeft, Bottom, BottomRight.
image:
  caption: ''
  focal_point: ''
  preview_only: false

# Projects (optional).
#   Associate this post with one or more of your projects.
#   Simply enter your project's folder or file name without extension.
#   E.g. `projects = ["internal-project"]` references `content/project/deep-learning/index.md`.
#   Otherwise, set `projects = []`.
projects: []
publishDate: '2021-04-06T13:49:36.058104Z'
publication_types:
- '2'
abstract: ''
publication: '*BMC Cancer*'
url_pdf: https://www.scopus.com/inward/record.uri?eid=2-s2.0-84996479973&doi=10.1186%2fs12885-016-2936-3&partnerID=40&md5=c36b00968a039c0ebe9d00b5f4ade152
doi: 10.1186/s12885-016-2936-3
---
