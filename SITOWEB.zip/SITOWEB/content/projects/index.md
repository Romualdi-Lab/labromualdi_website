+++
# projects page
title = "Projects"
summary = "Projects"
type = "widget_page"
headless = false  # Homepage is headless, other widget pages are not.
+++
