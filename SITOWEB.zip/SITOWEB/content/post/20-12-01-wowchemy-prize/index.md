---
date: "2019-03-21"
title: Our tool MOSCLIP is out on NAR
---
Our new method for multi-omic data integration in the framework of pathway analysis has been accepted on NAR and the journal dedicated the cover of the August issue to our tool  !
<img align='left' alt = 'mosclip' width='200' src='/media/mosclip.jpg'> 

<!--more-->



Try it on git ! https://github.com/cavei/MOSClip