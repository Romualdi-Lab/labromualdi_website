---
date: "2020-12-01"
title: Our new paper on CNV alterations in ctDNA  in high grade serous ovarian cancer is out !
---

Our new paper on genome-wide copy number alterations in ctDNA as a promising biomarker in high grade serous ovarian cancer.

<!--more-->

