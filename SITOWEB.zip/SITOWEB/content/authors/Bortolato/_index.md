---

bio: My research interests biostatistical models applied to cancer genomics
  matter.
education:
  courses:
  - course: PhD in Artificial Intelligence
    institution: Stanford University
    year: 2012
  - course: MEng in Artificial Intelligence
    institution: Massachusetts Institute of Technology
    year: 2009
  - course: BSc in Artificial Intelligence
    institution: Massachusetts Institute of Technology
    year: 2008
email: ""
interests:
- Artificial Intelligence
- Computational Linguistics
- Information Retrieval
organizations:
- name: Stanford University
  url: ""
role: Professor of Artificial Intelligence
social:
- icon: envelope
  icon_pack: fas
  link: mailto:test@example.org
- icon: twitter
  icon_pack: fab
  link: https://twitter.com/GeorgeCushen
- icon: google-scholar
  icon_pack: ai
  link: https://scholar.google.co.uk/citations?user=sIwtMXoAAAAJ
- icon: github
  icon_pack: fab
  link: https://github.com/gcushen
superuser: false
title: Anna Bortolato
user_groups:
- Grad Students
---

Anna Bortolato is ...

Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed neque elit, tristique placerat feugiat ac, facilisis vitae arcu. Proin eget egestas augue. Praesent ut sem nec arcu pellentesque aliquet. Duis dapibus diam vel metus tempus vulputate.
