+++
# Software2 page
title = "Software"
summary = "Software"
type = "widget_page"
headless = false  # Homepage is headless, other widget pages are not.
+++
